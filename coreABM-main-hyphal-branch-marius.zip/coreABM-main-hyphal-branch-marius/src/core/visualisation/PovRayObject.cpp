//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#include <sstream>
#include <vector>

#include "core/basic/SphericCoordinate3D.h"
#include "core/basic/Coordinate3D.h"
#include "core/visualisation/PovRayObject.h"
#include "apps/hyphalGrowth/environment/CustomSurface.h"

std::string PovRayObject::getCamera(Coordinate3D location, Coordinate3D look_at, double angle) {
    std::ostringstream ss;
    ss << "camera {" << '\n';
    ss << "\tlocation <" << location.x << "," << location.y << "," << location.z << ">\n";
    ss << "\tlook_at <" << look_at.x << "," << look_at.y << "," << look_at.z << ">\n";
    if (angle != 53.0) {
        ss << "\tangle " << angle << '\n';
    }
    ss << "\tright x*image_width/image_height" << '\n';
    ss << "\t }" << '\n';

    return ss.str();

}

std::string PovRayObject::getBackground(const ColorRGB &color) {
    std::ostringstream ss;
    ss << "background {" << '\n';
    ss << "\tcolor rgb <" << color.getRed() << ",\t" << color.getGreen() << ",\t" << color.getBlue() << ">\t}" << '\n';
    return ss.str();

}

std::string
PovRayObject::getCylinder(Coordinate3D firstCenter, Coordinate3D secondCenter, double radius, ColorRGB color) {
    std::ostringstream ss;
    ss << "cylinder {" << '\n';
    ss << "\t<" << firstCenter.x << "," << firstCenter.y << "," << firstCenter.z << ">,<" << secondCenter.x << ","
       << secondCenter.y << "," << secondCenter.z << ">," << radius << '\n';
    ss << "\tpigment { color " << color.printPovColorRGBT() << " }" << '\n';
    ss << "\t}" << '\n';
    return ss.str();
}

std::string PovRayObject::getTriangle(Coordinate3D firstVertex, Coordinate3D secondVertex, Coordinate3D thirdVertex, ColorRGB color) {
    std::ostringstream ss;
    ss << "triangle {" << '\n';
    ss << "\t<" << firstVertex.x << "," << firstVertex.y << "," << firstVertex.z << ">,<" << secondVertex.x << ","
       << secondVertex.y << "," << secondVertex.z << ">," << "<" << thirdVertex.x << ","
       << thirdVertex.y << "," << thirdVertex.z << ">" << '\n';
    ss << "\tpigment { color " << color.printPovColorRGBT() << " }" << '\n';
    ss << "\t}" << '\n';
    return ss.str();
}

std::string PovRayObject::getHeightField(CustomSurface* surface, int grid_index_i, int grid_index_j, std::array<double, 16> a_ij_vector, const ColorRGB& color){
    std::ostringstream ss;
    std::ostringstream x;
    std::ostringstream y;
    x << "x";
    y << "y";

    std::array<int, 2> x_range = surface->getXRange();
    std::array<int, 2> y_range = surface->getYRange();
    std::array<float, 2> z_range = surface->getZRange();
    int const step_size = surface->getStepSize();

    int x_translation = (grid_index_i - abs(x_range[0]/step_size)) * step_size;
    int y_translation = (grid_index_j - abs(y_range[0]/step_size)) * step_size + step_size;
    float z_scale = z_range[1] - z_range[0];

    if (grid_index_i == 0 && grid_index_j == 0){
        ss << "global_settings { assumed_gamma 1 }\n";
        ss << "#declare Surface_Color = srgb <" << color.getRed() << ", " << color.getGreen() << ", " << color.getBlue() << ">;\n";
    }

    ss << "#declare foo = function(x, y) { " << a_ij_vector[0]  << " + "  << a_ij_vector[1] << " * " << x.str() << " + "
       << a_ij_vector[2] << " * " << x.str() << " * " << x.str()  << " + " << a_ij_vector[3] << " * " << x.str() << " * " << x.str() << " * " << x.str() << " + "
       << a_ij_vector[4] << " * " << y.str() << " + " << a_ij_vector[5] << " * " << x.str() << " * " << y.str() << " + "
       << a_ij_vector[6] << " * " << x.str() << " * " << x.str() << " * " << y.str() << " + " << a_ij_vector[7] << " * " << x.str() << " * " << x.str() << " * " << x.str() << " * " << y.str() << " + "
       << a_ij_vector[8] << " * " << y.str() << " * " << y.str()  << " + " << a_ij_vector[9] << " * " << x.str() << " * " << y.str() << " * " << y.str() << " + "
       << a_ij_vector[10] << " * " << x.str() << " * " << x.str()  << " * " << y.str() << " * " << y.str()  << " + " << a_ij_vector[11] << " * " << x.str() << " * " << x.str() << " * " << x.str() << " * " << y.str() << " * " << y.str()  << " + "
       << a_ij_vector[12] << " * " << y.str() << " * " << y.str() << " * " << y.str() << " + " << a_ij_vector[13] << " * " << x.str() << " * " << y.str() << " * " << y.str() << " * " << y.str() << " + "
       << a_ij_vector[14] << " * " << y.str() << " * " << y.str() << " * " << y.str() << " * " << x.str() << " * " << x.str() << " + "
       << a_ij_vector[15] << " * " << y.str() << " * " << y.str() << " * " << y.str() << " * " << x.str() << " * " << x.str() << " * " << x.str()
       << " }\n\n";

    ss << "height_field {\n";
    ss << "\tfunction " << 50 << ", " << 50 << " { (foo (x, y) - " << z_range[0] << ")/" << z_scale << " }\n";
    ss << "\tsmooth\n";
    ss << "\tpigment { color Surface_Color }\n";
    //z-scale on y-axis since povray defines the "height" as lying on y-axis
    ss << "\tscale <" << step_size << ", " << z_scale << ", " << step_size << ">\n";

    // important to rotate so that height field is oriented correctly (weirdly defined in POVRAY)
    ss << "\trotate <-90, 0, 0>\n";
    ss << "\trotate <0, 180, 0>\n";
    ss << "\trotate <0, 0, 180>\n";

    // translate to correct position depending on cell (Cell with index [N/2][M/2] is cell where topleft point is origin (e.g. 40x40 cells => index [20][20]
    ss << "\ttranslate <" << x_translation << ", " << y_translation << ", " << z_range[0] << ">\n";
    ss << "}\n\n";
    ss << "#undef foo\n";

    return ss.str();
}

std::string PovRayObject::getIsosurface(const std::string& surface_type, std::array<int, 2> surface_x_range, std::array<int, 2> surface_y_range, std::array<float, 2> surface_z_range, const ColorRGB& color){
    std::ostringstream ss;

    const double extension = 10.0;

    ss << "global_settings { assumed_gamma 1 }\n";
    ss << "#declare Surface_Color = srgb <" << color.getRed() << ", " << color.getGreen() << ", " << color.getBlue() << ">;\n";
    ss << "isosurface {\n";

    // Define function corresponding to surface type
    if (surface_type == "sinus"){
        double f = M_PI * 0.02;
        double a = 20.0;
        ss << "\tfunction { " << a << " * sin(" << f << " * x) - z }\n";
        ss << "\tevaluate 2*0.6, sqrt(2/(2*0.6)), 0.7\n";
        ss << "\topen\n";
        ss << "\tcontained_by { box { <" << surface_x_range[0]-extension << ", " << surface_y_range[0]-extension << ", " << surface_z_range[0]-extension << ">, <"
           << surface_x_range[1]+extension << ", " << surface_y_range[1]+extension << ", " << surface_z_range[1]+extension << "> } }\n";
    }
    else if (surface_type == "quadratic"){
        double a = 0.002;
        ss << "\tfunction { " << a << " * (x * x + x * y + y * y + x + y) - z }\n";
        ss << "\tevaluate 2*0.6, sqrt(2/(2*0.6)), 0.7\n";
        ss << "\topen\n";
        ss << "\tcontained_by { box { <" << surface_x_range[0]-extension << ", " << surface_y_range[0]-extension << ", "<< surface_z_range[0]-extension <<">, <"
           << surface_x_range[1]+extension << ", " << surface_y_range[1]+extension << ", " << surface_z_range[1]+extension << "> } }\n";
    }
    else if (surface_type == "HalfSphere"){
        double radius = 160;
        ss << "\tfunction { sqrt(pow(x,2) + pow(y,2) + pow(z+" << radius <<", 2)) - "<< radius <<" }\n";
        ss << "\tevaluate 2*0.6, sqrt(2/(2*0.6)), 0.7\n";
        ss << "\tcontained_by { box { <-" << 2*radius << ", -" << 2*radius << ", -"<< radius <<">, <" << 2*radius << ", " << 2*radius << ", 0> } }\n";
        }
    else{
        ss << "\tfunction { 0.0001 - z }\n";
        ss << "\tevaluate 2*0.6, sqrt(2/(2*0.6)), 0.7\n";
        ss << "\topen\n";
        ss << "\tcontained_by { box { <" << surface_x_range[0]-extension << ", " << surface_y_range[0]-extension << ", " << surface_z_range[0]-extension << ">, <"
           << surface_x_range[1]+extension << ", " << surface_y_range[1]+extension << ", " << surface_z_range[1]+extension << "> } }\n";
    }

    ss << "\tpigment { color Surface_Color }\n";
    ss << "}\n\n";

    return ss.str();
}

std::string PovRayObject::getIsosurface(const std::vector<std::vector<Coordinate3D>>& grid, int grid_index_i, int grid_index_j, std::array<float, 2> z_range, std::array<double, 16> a_ij_vector, const ColorRGB& color){
    std::ostringstream ss;
    std::ostringstream x;
    std::ostringstream y;

    int x_min = grid[grid_index_i][grid_index_j].x;
    int x_max = grid[grid_index_i+1][grid_index_j+1].x;
    int y_min = grid[grid_index_i][grid_index_j].y;
    int y_max = grid[grid_index_i+1][grid_index_j+1].y;

    x << "(x - " << x_min << ")/(" << x_max - x_min << ")";
    y << "(y - " << y_min << ")/(" << y_max - y_min << ")";

    ss << "global_settings { assumed_gamma 1 }\n";

    ss << "#declare foo = function(x, y) { " << a_ij_vector[0]  << " + "  << a_ij_vector[1] << " * " << x.str() << " + "
       << a_ij_vector[2] << " * " << x.str() << " * " << x.str()  << " + " << a_ij_vector[3] << " * " << x.str() << " * " << x.str() << " * " << x.str() << " + "
       << a_ij_vector[4] << " * " << y.str() << " + " << a_ij_vector[5] << " * " << x.str() << " * " << y.str() << " + "
       << a_ij_vector[6] << " * " << x.str() << " * " << x.str() << " * " << y.str() << " + " << a_ij_vector[7] << " * " << x.str() << " * " << x.str() << " * " << x.str() << " * " << y.str() << " + "
       << a_ij_vector[8] << " * " << y.str() << " * " << y.str()  << " + " << a_ij_vector[9] << " * " << x.str() << " * " << y.str() << " * " << y.str() << " + "
       << a_ij_vector[10] << " * " << x.str() << " * " << x.str()  << " * " << y.str() << " * " << y.str()  << " + " << a_ij_vector[11] << " * " << x.str() << " * " << x.str() << " * " << x.str() << " * " << y.str() << " * " << y.str()  << " + "
       << a_ij_vector[12] << " * " << y.str() << " * " << y.str() << " * " << y.str() << " + " << a_ij_vector[13] << " * " << x.str() << " * " << y.str() << " * " << y.str() << " * " << y.str() << " + "
       << a_ij_vector[14] << " * " << y.str() << " * " << y.str() << " * " << y.str() << " * " << x.str() << " * " << x.str() << " + "
       << a_ij_vector[15] << " * " << y.str() << " * " << y.str() << " * " << y.str() << " * " << x.str() << " * " << x.str() << " * " << x.str()
       << " }\n\n";

    ss << "isosurface {\n";
    ss << "\tfunction { foo (x, y)-z }\n";
    ss << "\tcontained_by { box { <" << x_min << ", " << y_min << ", " << z_range[0]-1 << ">, <" << x_max << ", " << y_max << ", " << z_range[1]+1 << "> } }\n";
    ss << "\tevaluate 2*0.6, sqrt(2/(2*0.6)), 0.7\n";
    ss << "\topen\n";
    ss << "\tpigment { color srgb <" << color.getRed() << ", " << color.getGreen() << ", " << color.getBlue() << "> }\n";
    ss << "}\n\n";
    ss << "#undef foo\n";
    return ss.str();
}

std::string PovRayObject::getLightsource(Coordinate3D position) {
    std::ostringstream ss;
    ss << "light_source {" << '\n';
    ss << "\t<" << position.x << "," << position.y << "," << position.z << ">\n";
    ss << "\trgb <1,1,1>" << '\n';
    ss << "\tshadowless" << '\n';
    ss << "\t}" << '\n';

    return ss.str();
}

std::string PovRayObject::getSphere(Coordinate3D center, double radius, ColorRGB color) {
    std::ostringstream ss;
    ss << "sphere {" << '\n';
    ss << "\t<" << center.x << "," << center.y << "," << center.z << ">," << "\n";
    ss << "\t" << radius << '\n';
    ss << "\t" << "pigment { color " << color.printPovColorRGBT() << " }" << '\n';
    ss << "\t}" << '\n';

    return ss.str();
}

std::string PovRayObject::getBox(Coordinate3D leftDown, Coordinate3D rightUp, ColorRGB color) {
    std::ostringstream ss;
    ss << "box {" << '\n';
    ss << "\t<" << leftDown.x << "," << leftDown.y << "," << leftDown.z << ">,<" << rightUp.x << "," << rightUp.y << ","
       << rightUp.z << ">\n";
    ss << "\t" << "pigment { color " << color.printPovColorRGBT() << " }" << '\n';
    ss << "\t}" << '\n';

    return ss.str();
}

std::string
PovRayObject::getBox(Coordinate3D left_down, Coordinate3D right_up, ColorRGB color, SphericCoordinate3D rotate,
                     Coordinate3D translate) {
    std::ostringstream ss;
    ss << "box {" << '\n';
    ss << "\t<" << left_down.x << "," << left_down.y << "," << left_down.z << ">,<" << right_up.x << "," << right_up.y
       << "," << right_up.z << ">\n";
    ss << "\t rotate <0," << rotate.theta * 180.0 / M_PI << ",0>" << '\n';
    ss << "\t rotate <0,0," << rotate.phi * 180.0 / M_PI << ">" << '\n';
    ss << "\t translate <" << translate.x << "," << translate.y << "," << translate.z << ">\n";
    ss << "\t" << "pigment { color " << color.printPovColorRGBT() << " }" << '\n';
    ss << "\t}" << '\n';

    return ss.str();
}

std::string
PovRayObject::getTorus(Coordinate3D center, double innerRad, double outerRad, Coordinate3D rotation, ColorRGB *color) {
    std::ostringstream oss;
    oss << "torus {\n";
    oss << "\t" << outerRad << ", " << innerRad << "\n";
    //important: rotation before translation
    oss << "\trotate <" << rotation.x << "," << rotation.y << "," << rotation.z << ">\n";
    oss << "\t translate <" << center.x << "," << center.y << "," << center.z << ">\n";
    oss << "\t" << "pigment { color " << color->printPovColorRGBT() << " }" << '\n';
    oss << "\n}\n";
    return oss.str();
}

std::string PovRayObject::getIntersection(const std::string &objOne, const std::string &objTwo) {
    std::ostringstream ss;
    ss << "intersection {" << '\n';
    ss << "\t" << objOne << '\n';
    ss << "\t" << objTwo << '\n';
    ss << "\t}" << '\n';

    return ss.str();
}

std::string PovRayObject::getIntersection(const std::string &objOne, const std::vector<std::string> &objectsTwo) {
    std::ostringstream ss;
    ss << "intersection {" << '\n';
    ss << "\t" << objOne << '\n';

    for (const auto &it : objectsTwo) {
        ss << "\t" << it << '\n';
    }

    ss << "\t}" << '\n';

    return ss.str();
}

std::string PovRayObject::getDifference(const std::string &objOne, const std::string &objTwo) {
    std::ostringstream ss;
    ss << "difference {" << '\n';
    ss << "\t" << objOne << '\n';
    ss << "\t" << objTwo << '\n';
    ss << "\t}" << '\n';

    return ss.str();
}

std::string PovRayObject::getDifference(const std::string &objOne, const std::vector<std::string> &objectsTwo) {
    std::ostringstream ss;
    ss << "difference {" << '\n';
    ss << "\t" << objOne << '\n';
    for (const auto &it : objectsTwo) {
        ss << "\t" << it << '\n';
    }
    ss << "\t}" << '\n';

    return ss.str();
}
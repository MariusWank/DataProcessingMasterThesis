//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#include "core/visualisation/PovFile.h"
#include "apps/hyphalGrowth/CuboidSiteHyphalGrowth.h"
#include "core/simulation/Site.h"
#include "core/utils/io_util.h"
#include "core/utils/macros.h"
#include "core/visualisation/PovRayObject.h"
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/split.hpp>

PovFile::PovFile(const std::string &filebody) {
    filebody_pov_ = filebody;
}

void PovFile::setGlobalPart(std::string global) {
    global_part_ = global;
}

void PovFile::setCameraPart(std::string cam) {
    camera_part_ = cam;
}

void PovFile::setBackgroundPart(std::string bg) {
    background_part_ = bg;
}

void PovFile::setLightPart(std::string light) {
    light_part_ = light;
}

void PovFile::addLightPart(const std::string &light) {
    light_part_ += light;
}

void PovFile::setBorderPart(std::string border) {
    border_part_ = border;
}

void PovFile::addPovObject(const std::string &povObj) {
    pov_objects_.emplace_back(povObj);
}

void PovFile::setDimensions(const std::string px_width, const std::string px_height) {
    px_width_ = px_width, px_height_ = px_height;
}

void PovFile::setIncludeTime(bool include_time) {
    include_time_ = include_time;
}

void PovFile::setRenderQuality(int render_quality) {
    render_quality_ = render_quality;
}

void PovFile::doPovProcess(double current_time, std::string zpos) {
    std::ofstream output(filebody_pov_ + zpos + ".pov");
    output << global_part_ << '\n';
    output << camera_part_ << '\n';
    output << light_part_ << '\n';
    output << border_part_ << '\n';
    output << background_part_ << '\n';
    for (const auto &obj: pov_objects_) {
        output << obj << '\n';
    }
    output.close();
    int left_padding = static_cast<int>(stoi(px_width_) / 5);
    int below_padding = 50;
    int font_size = static_cast<int>(stoi(px_height_) / 30);
    std::string font_color = "black";
    int X = std::stoi(px_width_) - left_padding;
    int Y = std::stoi(px_height_) - below_padding;
    char timeOfFrame[20];
    sprintf(timeOfFrame, "%.3f", current_time);
    std::ostringstream command;
    command << "povray -GA -d +H" << px_height_ << " +W" << px_width_ << " +Q" << render_quality_ << " +I" << filebody_pov_ << zpos << ".pov +O"
            << filebody_pov_ << zpos << ".png >/dev/null 2>&1 ";
    if (include_time_) {
        command << "&& convert -pointsize " << font_size << " -fill " << font_color << " -draw \"text " << X << " " << Y
                << " '" << timeOfFrame
                << " min'\" " << filebody_pov_ << zpos << ".png " << filebody_pov_ << ".png ";
    }
    command << "&& rm -f " << filebody_pov_ << zpos << ".pov";

    DEBUG_STDOUT("Started POV Visualization of scene at " << current_time << " minutes!");
    abm::util::executeShellCommand(command.str(), true);
}

void PovFile::transcribeSite(Site &site) {
    // set background color
    addPovObject("background { color rgb <0.9, 0.9, 0.9> }");

    if (abm::util::isSubstring("CuboidSite", site.getType())) {
        auto lowerBoundReal = site.getLowerLimits();
        auto upperBoundReal = site.getUpperLimits();
        double extension = 10.0;
        double thickness = 1.5;
        double threshold_2d = 30.0;
        Coordinate3D bound_extension = {1.0, 1.0, 1.0};
        bound_extension *= extension;
        auto lowerBound = lowerBoundReal - bound_extension;
        auto upperBound = upperBoundReal + bound_extension;
        Coordinate3D point1, point2, point3, point4, point5, point6, point7, point8;
        point1 = lowerBound;
        point2 = Coordinate3D{upperBound.x, lowerBound.y, lowerBound.z};
        point3 = Coordinate3D{upperBound.x, upperBound.y, lowerBound.z};
        point4 = Coordinate3D{lowerBound.x, upperBound.y, lowerBound.z};
        point5 = Coordinate3D{lowerBound.x, upperBound.y, upperBound.z};
        point6 = Coordinate3D{lowerBound.x, lowerBound.y, upperBound.z};
        point7 = Coordinate3D{upperBound.x, lowerBound.y, upperBound.z};
        point8 = upperBound;

        ColorRGB colorBounds = ColorRGB(0.3, 0.3, 0.3, 0.3);//(0.5, 0.5, 0.5, 0.5);
        if (abs(lowerBoundReal.z - upperBoundReal.z) < threshold_2d) {
            //two-dimensional case
            addPovObject(PovRayObject::getCylinder(point1, point2, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point2, point3, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point3, point4, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point1, point4, thickness, colorBounds));
        } else {
            //three-dimensional case
            addPovObject(PovRayObject::getCylinder(point1, point2, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point2, point3, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point3, point4, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point1, point4, thickness, colorBounds));

            addPovObject(PovRayObject::getCylinder(point5, point6, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point6, point7, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point7, point8, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point8, point5, thickness, colorBounds));

            addPovObject(PovRayObject::getCylinder(point4, point5, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point1, point6, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point2, point7, thickness, colorBounds));
            addPovObject(PovRayObject::getCylinder(point3, point8, thickness, colorBounds));
        }
    }
}

void PovFile::transcribeSurface(Site &site) {
    auto vis_parameters = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getVisualizationParameters();
    std::string const surface_type = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getSurfaceType();
    std::vector<double> surface_color_vector = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getVisualizationParameters().surface_color;
    ColorRGB surface_color = {surface_color_vector[0]/255.0, surface_color_vector[1]/255.0, surface_color_vector[2]/255.0};
    const std::vector<std::vector<Coordinate3D>>& grid = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getCustomSurface().getGrid();
    std::array<float, 2> surface_z_range = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getZRange();

    if (surface_type == "randomSurface" || surface_type.find(".csv") != std::string::npos) {
        // get Grid from upper Surface
        const CustomSurface* upper_custom_surface = &dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getCustomSurface();
        const CustomSurface* lower_custom_surface = &dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getLowerEnvSurface().getCustomSurface();
        std::vector<std::vector<std::array<double, 16>>> upper_a_ij_matrix = upper_custom_surface->get_a_ij_matrix();
        std::vector<std::vector<std::array<double, 16>>> lower_a_ij_matrix = lower_custom_surface->get_a_ij_matrix();
        int const number_of_rows = upper_custom_surface->getDimensions()[0];
        int const number_of_cols = upper_custom_surface->getDimensions()[1];

        if (upper_custom_surface->getInterpolationType() == "bicubic") {
            // Visualization for bicubic interpolation using POVRAY height field objects
            for (int i = 0; i < number_of_rows-1; i++) {
                #pragma unroll 5
                for (int j = 0; j < number_of_cols-1; j++) {
                    addPovObject(PovRayObject::getIsosurface(grid, i, j,surface_z_range, upper_a_ij_matrix[i][j], surface_color));
                    if (vis_parameters.visualize_lower_surface) {
                        addPovObject(PovRayObject::getIsosurface(grid, i, j, surface_z_range, lower_a_ij_matrix[i][j], surface_color));
                    }
                }
            }
        } else { // Visualization with triangles
            // Define variables
            Coordinate3D current_point{};
            Coordinate3D point_to_the_right{};
            Coordinate3D point_below{};
            Coordinate3D point_diagonally{};

            // only for points that are not at the bottom or right border of the grid
            for (int i = 0; i < number_of_rows - 1; i++) {
                #pragma unroll 5
                for (int j = 0; j < number_of_cols - 1; j++) {
                    // define current point
                    current_point = grid[i][j];

                    // TODO: Recursive algorithm to generate more triangles for radial interpolation?
                    // define remaining points necessary for triangle generation
                    point_to_the_right = grid[i + 1][j];
                    point_below = grid[i][j + 1];
                    point_diagonally = grid[i + 1][j + 1];
                    // add 2 Triangles per point
                    addPovObject(PovRayObject::getTriangle(current_point, point_diagonally, point_below, surface_color));
                    addPovObject(PovRayObject::getTriangle(current_point, point_diagonally, point_to_the_right, surface_color));
                }
            }
        }
    }
    else{
        std::array<int, 2> surface_x_range = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getXRange();
        std::array<int, 2> surface_y_range = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getYRange();
        addPovObject(PovRayObject::getIsosurface(surface_type, surface_x_range, surface_y_range, surface_z_range, surface_color));
    }
}

void PovFile::transcribeGrid(Site &site) {

    std::string surface_type = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getSurfaceType();
    std::vector<double> surface_color_vector = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getVisualizationParameters().surface_color;
    ColorRGB surface_color = {surface_color_vector[0] / 255.0, surface_color_vector[1] / 255.0, surface_color_vector[2] / 255.0};

    if (surface_type == "randomSurface" || surface_type.find(".csv") != std::string::npos) {
        // get Grid from Surface
        const CustomSurface* custom_surface = &dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getCustomSurface();
        const std::vector<std::vector<Coordinate3D>>& grid = dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getEnvSurface().getCustomSurface().getGrid();
        int const number_of_rows = custom_surface->getDimensions()[0];
        int const number_of_cols = custom_surface->getDimensions()[1];

        // Visualization for bicubic interpolation using POVRAY height field objects
        for (int i = 0; i < number_of_rows; i++) {
            #pragma unroll 5
            for (int j = 0; j < number_of_cols; j++) {
                addPovObject(PovRayObject::getSphere(grid[i][j], 0.35, surface_color));
            }
        }
    }
}

void PovFile::transcribeAgents(Site &site) {
    // Create color vector for all colors to be used in visualization, the first being base color
    std::vector<ColorRGB> colors;

    colors.emplace_back(165.0/255.0, 15.0/255.0, 21.0/255.0); //base color
    colors.emplace_back(222.0/255.0, 45.0/255.0, 38.0/255.0);
    colors.emplace_back(251.0/255.0, 106.0/255.0, 74.0/255.0);
    colors.emplace_back(252.0/255.0, 146.0/255.0, 114.0/255.0);
    colors.emplace_back(252.0/255.0, 187.0/255.0, 161.0/255.0);
    colors.emplace_back(254.0/255.0, 229.0/255.0, 217.0/255.0);

    // Initialize color pointer
    ColorRGB *color = nullptr;

    for (auto agent: *site.getAgentManager()) {
        #pragma unroll 5
        for (auto *sphere: agent->getSurface()->getAllSpheresOfThis()) {
            auto position = sphere->getPosition();
            auto radius = sphere->getRadius();
            if (agent->getTypeName() == "FungalCellHyphalGrowth" && sphere->getDescription() != "basic" && dynamic_cast<CuboidSiteHyphalGrowth*>(&site)->getVisualizationParameters().visualize_depth){
                std::vector<std::string> id_and_depth_storage;
                boost::split(id_and_depth_storage, sphere->getDescription(), boost::is_any_of("_"));
                DEBUG_STDOUT(id_and_depth_storage[1]);
                color = &colors[(std::stoi(id_and_depth_storage[1])-1)];
            }
            else{
                color = &colors[0];
            }
            addPovObject(PovRayObject::getSphere(position, radius, *color));
        }
    }
}
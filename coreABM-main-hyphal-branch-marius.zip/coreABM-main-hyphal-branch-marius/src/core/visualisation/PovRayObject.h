//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#ifndef CORE_VISUALISATION_POVRAYOBJECT_H
#define CORE_VISUALISATION_POVRAYOBJECT_H

#include "apps/hyphalGrowth/environment/CustomSurface.h"
#include "core/basic/ColorRGB.h"
#include "core/basic/Coordinate3D.h"

class PovRayObject {
public:
    static std::string getSphere(Coordinate3D center, double radius, ColorRGB color);
    static std::string getBox(Coordinate3D leftDown, Coordinate3D rightUp, ColorRGB color);
    static std::string getBox(Coordinate3D leftDown, Coordinate3D rightUp, ColorRGB color, SphericCoordinate3D rotate,
                              Coordinate3D translate);
    static std::string getCylinder(Coordinate3D firstCenter, Coordinate3D secondCenter, double radius, ColorRGB color);
    static std::string getLightsource(Coordinate3D);
    static std::string getBackground(const ColorRGB &color);
    static std::string getCamera(Coordinate3D location, Coordinate3D look_at, double angle = 53.0);
    static std::string
    getTorus(Coordinate3D center, double innerRad, double outerRad, Coordinate3D rotation, ColorRGB *color);
    static std::string getIntersection(const std::string &objOne, const std::string &objTwostatic);
    static std::string getIntersection(const std::string &objOne, const std::vector<std::string> &objectsTwo);
    static std::string getDifference(const std::string &objOne, const std::string &objTwo);
    static std::string getDifference(const std::string &objOne, const std::vector<std::string> &objectsTwo);
    static std::string getTriangle(Coordinate3D firstVertex, Coordinate3D secondVertex, Coordinate3D thirdVertex, ColorRGB color);
    static std::string  getHeightField(CustomSurface* surface, int grid_index_i, int grid_index_j, std::array<double, 16> a_ij_vector, const ColorRGB& color);
    static std::string getIsosurface(const std::string& surface_type, std::array<int, 2> surface_x_range, std::array<int, 2> surface_y_range, std::array<float, 2> surface_z_range, const ColorRGB& color);
    static std::string getIsosurface(const std::vector<std::vector<Coordinate3D>>& grid, int grid_index_i, int grid_index_j, std::array<float, 2> z_range, std::array<double, 16> a_ij_vector, const ColorRGB& color);
};

#endif /* CORE_VISUALISATION_POVRAYOBJECT_H */
//
// Created by ybachelot on 24.04.23.
//

#include "AnalyserExample.h"

AnalyserExample::AnalyserExample(const std::string& config_path, const std::string& project_dir)
    : Analyser( std::move(config_path), std::move(project_dir)){}

std::shared_ptr<InSituMeasurements> AnalyserExample::generateMeasurement(const std::string& id) const {
    std::shared_ptr<InSituMeasurementsExample> new_measurement = nullptr;
#pragma omp critical
    {
        new_measurement = measurements_.emplace_back(
            std::make_shared<InSituMeasurementsExample>(parameters_.active_measurements, id));
    }
    return new_measurement;
}
//
// Created by ybachelot on 24.04.23.
//

#ifndef COREABM_ANALYSEREXAMPLE_H
#define COREABM_ANALYSEREXAMPLE_H

#include "InSituMeasurementsExample.h"
#include "core/analyser/Analyser.h"

class AnalyserExample : public Analyser{
  public:
    AnalyserExample(const std::string &config_path, const std::string &project_dir);
    std::shared_ptr<InSituMeasurements> generateMeasurement(const std::string &id) const override;

  protected:
    mutable std::vector<std::shared_ptr<InSituMeasurementsExample>> measurements_;
};

#endif // COREABM_ANALYSEREXAMPLE_H

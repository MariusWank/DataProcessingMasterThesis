//
// Created by ybachelot on 24.04.23.
//

#ifndef COREABM_INSITUMEASUREMENTSEXAMPLE_H
#define COREABM_INSITUMEASUREMENTSEXAMPLE_H

#include "core/analyser/InSituMeasurements.h"


class InSituMeasurementsExample : public InSituMeasurements {
  public:
    InSituMeasurementsExample(std::unordered_set<std::string> active_measurements, const std::string &);
    void observeMeasurements(const SimulationTime &time);
};

#endif // COREABM_INSITUMEASUREMENTSEXAMPLE_H

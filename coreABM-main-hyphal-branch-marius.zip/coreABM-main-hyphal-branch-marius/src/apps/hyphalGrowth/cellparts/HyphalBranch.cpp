//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#include "HyphalBranch.h"

#include <math.h>
#include "apps/hyphalGrowth/CuboidSiteHyphalGrowth.h"
#include "apps/hyphalGrowth/FungalCellHyphalGrowth.h"

HyphalBranch::HyphalBranch(Cell *mothercell, const std::shared_ptr<Coordinate3D> &connection_point, int depth, Coordinate3D growth_vector, HyphalBranch* parent)
        : AssociatedCellparts(mothercell, connection_point), hyphal_tip_(connection_point), depth_(depth + 1), growth_vector_(growth_vector), parent_branch_(parent) {

    // Set upper and lower surface
    surface_ = &dynamic_cast<CuboidSiteHyphalGrowth*>(mothercell->getSite())->getEnvSurface();
    lower_surface_ = &dynamic_cast<CuboidSiteHyphalGrowth*>(mothercell->getSite())->getLowerEnvSurface();

    // Set parameters
    set_parameters();

    // Set growth vector direction
    if (depth_ == 1) {
        growth_weights_ = abm::util::getRandom2Direction(mothercell->getSite()->getRandomGenerator());
    } else {
        growth_weights_ = { 1.0, 0.0};
    }

    //TODO: sphere created for emphasizing branching points
    auto new_sphere_pos = Coordinate3D({connection_point->x,connection_point->y, connection_point->z});
    auto new_sphere = std::make_unique<SphericalMorphology>(mothercell->getSurface(), std::make_shared<Coordinate3D>(new_sphere_pos), 1.1*radius_, "null_" + std::to_string(depth_), pierced_);
    auto new_sphere_rep = new_sphere->getSphereRepresentation().front();
    mothercell->getSurface()->appendAssociatedCellpart(std::move(new_sphere));
    update_growth_vector();
}

void HyphalBranch::set_parameters() {
    // Set all relevant parameters
    id_ = static_cast<FungalCellHyphalGrowth*>(mothercell)->getNumberOfBranches();
    static_cast<FungalCellHyphalGrowth*>(mothercell)->increaseNumberOfBranches();
    DEBUG_STDOUT("Create new branch with id=" << id_);

    growing_ = true;
    radius_ = mothercell->getSurface()->getBasicSphereOfThis()->getRadius() * 0.66;
    step_length_ = radius_ * 0.95;
    set_collision_threshold();
    next_sphere_threshold_ = 0.0;

    auto hg_paras = static_cast<FungalCellHyphalGrowth*>(mothercell)->getHyphalParameter();

    // Evasion
    evasion_ = hg_paras->evasion;

    // Curvature
    cp.next_curve_mean = hg_paras->cp.next_curve_mean;
    cp.angle_mean = hg_paras->cp.angle_mean;
    new_dirction_threshold_ = cp.next_curve_mean;

    // Branching
    bp.depth_dependency = hg_paras->bp.depth_dependency;
    bp.next_branch_mean = hg_paras->bp.next_branch_mean + bp.depth_dependency * (depth_ - 1);
    bp.angle_mean = hg_paras->bp.angle_mean;
    next_branch_threshold_ = bp.next_branch_mean;
    bp.apical_branch_probability = hg_paras->bp.apical_branch_probability;
    bp.symmetry_probability = hg_paras->bp.symmetry_probability;
    if(parent_branch_== nullptr){
        bp.branch_delay = 0.0;
    }

    // Growth
    branch_length_ = 0.0;
    gp.k1 = hg_paras->gp.k1; // removed quadratic depth dependency
    gp.k2 = hg_paras->gp.k2;
    gp.sat_length = hg_paras->gp.sat_length;
}

void HyphalBranch::update_growth_vector() {
    // Update the growth vector direction

    // Select surface of current branch; don't update growth vector if branch is currently piercing
    bool on_lower_surface;
    const Surface* current_surface = nullptr;
    if (!pierced_) {
        current_surface = surface_;
        on_lower_surface = false;
    } else if (pierced_ && pierce_distance_ >= lower_surface_->get_distance_from_upper_surface()) {
        current_surface = lower_surface_;
        on_lower_surface = true;
    } else {
        return;
    }

    // If branch is not evading, select growth vector based on gradient of selected surface
    if (eState == EvasionState::NORMAL) {
        hyphal_tip_ = std::make_shared<Coordinate3D>(current_surface->surfacePoint(*hyphal_tip_)); // Here for working evasion; needs to get growth vector of surface

        if (growth_vector_.getMagnitude() == 0.0) {
            auto uvecs = current_surface->perpendicularVectors(*hyphal_tip_);
            growth_vector_ = uvecs.first * growth_weights_.first + uvecs.second * growth_weights_.second;
            growth_vector_ *= step_length_ / growth_vector_.getMagnitude();
        } else {
            growth_vector_90_deg_ = current_surface->perpendicularVector(*hyphal_tip_, growth_vector_);
            growth_vector_90_deg_ *= step_length_ / growth_vector_90_deg_.getMagnitude();
            growth_vector_ = current_surface->perpendicularVector(*hyphal_tip_, growth_vector_90_deg_ * (-1));
            growth_vector_ *= step_length_ / growth_vector_.getMagnitude();
            Coordinate3D newVec =
                    growth_vector_ * growth_weights_.first + growth_vector_90_deg_ * growth_weights_.second;
            newVec *= step_length_ / newVec.getMagnitude(); // makes sure that magnitude == step_length_
            growth_vector_ = newVec;
        }
    } else {
        growth_vector_ = evasion_growth_vector_;
    }
    growth_weights_ = {1.0, 0.0};
}

void HyphalBranch::set_collision_threshold() {
    // Each sphere has always collisions since they are forming the hyphae
    // To detect collisions we set the collision_threshold depending on the ratio step_length/radius
    collision_threshold = step_length_ / radius_ <= 1/2 ? 4 : 3;
    collision_threshold = step_length_ / radius_ > 1.5 ? 2 : collision_threshold;
}

double HyphalBranch::add_branch_length_change(double timestep){
    // Get hyphal length depending on timestep and depth of branch
    return (gp.k1/depth_ + gp.k2 * (branch_length_ / (gp.sat_length + branch_length_))) * timestep;
}

// Function to get all subbranches recursively
std::set<HyphalBranch*> HyphalBranch::getAllSubbranches() {
    std::set<HyphalBranch*> allSubbranches;
    // Add the current branch
    allSubbranches.insert(this);
    #pragma unroll (5)
    for (auto& branch : hyphal_branches_) {
        // Recursively get subbranches of the current branch
        auto subSubbranches = branch->getAllSubbranches();
        allSubbranches.insert(subSubbranches.begin(), subSubbranches.end());
    }
    return allSubbranches;
}

void HyphalBranch::pierce(){
    // Flag current branch as pierced and change growth vector to force growth in negative z-direction
    pierced_ = true;
    growth_vector_ = {0.0, 0.0, -1.0};
    growth_vector_ *= step_length_ / growth_vector_.getMagnitude();
    DEBUG_STDOUT("Branch has pierced!");
}

void HyphalBranch::grow(double timestep, double current_time) {

    double distance_to_parent = 0.0;
    if(parent_branch_) {
        distance_to_parent = parent_branch_->hyphal_tip_->calculateEuclidianDistance(*hyphal_tip_);
    }


    // Only start growth algorithm if branch is marked as growing and delay for lateral branching has not passed
    if (growing_ && distance_to_parent >= bp.branch_delay) {

        // Add hyphal length for current timestep
        branch_length_ += add_branch_length_change(timestep);

        // Calculate new direction for HyphalBranch
        if (branch_length_ > new_dirction_threshold_) {
            growth_weights_ = abm::util::getRandom2Direction(mothercell->getSite()->getRandomGenerator(), cp.angle_mean, 0);
            update_growth_vector();
            new_dirction_threshold_ += mothercell->getSite()->getRandomGenerator()->generateNormalDistributedValue(cp.next_curve_mean, 0);
        }

        const int num_subdivisions = 100; // Set number of subdivision for growth vector for accurate growth

        // Add one sphere for every step_length that fits in new branch_length
        for (; branch_length_ > next_sphere_threshold_ + step_length_; next_sphere_threshold_ += step_length_) { //step_length must be used for scaling magnitude of growth_vector only

            // Create new sphere pos
            auto new_sphere_pos = std::make_shared<Coordinate3D>();

            // Only use subdivision for accurate hyphal growth on surface if not evading (Evasion doesn't happen on surface but above it)
            if (eState == EvasionState::NORMAL){
                #pragma unroll (5)
                for (int num = 0; num < num_subdivisions; num++){
                    *hyphal_tip_ += growth_vector_/num_subdivisions;
                    update_growth_vector();
                }
                *new_sphere_pos = *hyphal_tip_;
            }else{
                *new_sphere_pos = *hyphal_tip_ + growth_vector_;
            }
            update_growth_vector();

            // Check if new sphere pos is inside environment; if not growth is stopped
            if (mothercell->getSite()->containsPosition(*new_sphere_pos))  {

                // Add new sphere representation, but only add after Evasion check
                auto add_sphere = true;
                auto new_sphere = std::make_unique<SphericalMorphology>(mothercell->getSurface(), new_sphere_pos, radius_, std::to_string(id_) + "_" + std::to_string(depth_), current_time, pierced_);
                auto new_sphere_rep = new_sphere->getSphereRepresentation().front();

                // Evasion only if it has outgrown its motherbranch
                if (branch_length_ > 5 * radius_ && !pierced_ && evasion_) {
                    collisions = mothercell->getSite()->getNeighbourhoodLocator()->getCollisionSpheres(new_sphere_rep.get(), growth_vector_);

                    // based on how many collisions a sphere has, we decide if it is hitting a different branch
                    // depends on distance between spheres in the hyphae
                    if (collisions.size() > collision_threshold) {
                        add_sphere = false;
                        evasion_growth_vector_ = growth_vector_;

                        if (eState == EvasionState::NORMAL) {
                            eState = EvasionState::GO_UP;
                        } else if (eState == EvasionState::GO_DOWN) {
                            eState = EvasionState::GO_STRAIGHT;
                            if (evasion_tries > 1) {
                                eState = EvasionState::GO_UP;
                            }
                        } else if (eState == EvasionState::GO_STRAIGHT) {
                            if (evasion_tries > 1) {
                                eState = EvasionState::GO_UP;
                            }
                        }
                        mothercell->getSite()->getNeighbourhoodLocator()->removeSphereRepresentation(new_sphere_rep.get());
                        next_sphere_threshold_ -= step_length_;
                        evasion_tries += 1;
                        if (evasion_tries > 9) { // after 9 evasion tries, it stops growing here
                            growing_ = false;
                            next_sphere_threshold_ += step_length_;
                        }

                    } else {
                        if (eState == EvasionState::GO_DOWN) {
                            surface_ = &static_cast<CuboidSiteHyphalGrowth*>(mothercell->getSite())->getEnvSurface();
                            auto current_position = new_sphere_rep->getPosition();
                            auto distance_to_z_level = current_position.z - surface_->surfacePoint(current_position).z;
                            if (distance_to_z_level <= 0.0) {
                                add_sphere = false;
                                mothercell->getSite()->getNeighbourhoodLocator()->removeSphereRepresentation(new_sphere_rep.get());
                                eState = EvasionState::NORMAL;
                                update_growth_vector();
                                evasion_tries = 0;
                            }
                        } else if (eState == EvasionState::GO_STRAIGHT) {
                            eState = EvasionState::GO_DOWN;
                            evasion_tries = 0;
                        } else if (eState == EvasionState::GO_UP) {
                            eState = EvasionState::GO_STRAIGHT;
                            evasion_tries = 0;
                        }
                    }
                }

                if (eState != EvasionState::NORMAL) { // collision is taking place
                    double factor = 0.5; // factor of evasion steepness (the higher the value, the steeper)
                    if (eState == EvasionState::GO_UP) { // go up
                        auto evasion_vec = evasion_growth_vector_ - surface_->surfaceNormal(*hyphal_tip_) * factor;
                        evasion_vec *= step_length_/evasion_vec.getMagnitude();
                        evasion_growth_vector_ = evasion_vec;
                    } else if (eState == EvasionState::GO_DOWN) { // go down
                        auto evasion_vec = evasion_growth_vector_ + surface_->surfaceNormal(*hyphal_tip_) * factor;
                        evasion_vec *= step_length_/evasion_vec.getMagnitude();
                        evasion_growth_vector_ = evasion_vec;
                    } else if (eState == EvasionState::GO_STRAIGHT) { // go straight
                        evasion_growth_vector_ = growth_vector_;
                    }
                }

                // If evasion did not happen or was done successfully: add sphere
                if (add_sphere) {

                    // If branch is still piercing update the pierced distance
                    if (pierced_ && pierce_distance_ < lower_surface_->get_distance_from_upper_surface()){
                        pierce_distance_ += step_length_;
                    }

                    // If branch reached lower surface after piercing, set hyphal tip to be on the lower surface and reset growth vector
                    if (pierce_distance_ > lower_surface_->get_distance_from_upper_surface()){
                        pierce_distance_ = lower_surface_->get_distance_from_upper_surface();
                        hyphal_tip_ = std::make_shared<Coordinate3D>(lower_surface_->surfacePoint(*hyphal_tip_));
                        growth_vector_ = Coordinate3D {0, 0, 0};
                        growth_weights_ = abm::util::getRandom2Direction(mothercell->getSite()->getRandomGenerator());
                    }else{
                        hyphal_tip_ = new_sphere_pos;
                    }
                    update_growth_vector();
                    mothercell->getSurface()->appendAssociatedCellpart(std::move(new_sphere));
                }
            } else {
                growing_ = false;
                DEBUG_STDOUT("Stop growth, reached end of site");
            }
        }

        // If branch hasn't pierced and threshold is reached: create new branch
        if (branch_length_ > next_branch_threshold_ && (!pierced_ || pierce_distance_ >= lower_surface_->get_distance_from_upper_surface())) {

            // Create a new branch
            std::unique_ptr<HyphalBranch> new_branch = std::make_unique<HyphalBranch>(mothercell, hyphal_tip_, depth_, growth_vector_,this);

            // decide weather apical or lateral branching
            if (mothercell->getSite()->getRandomGenerator()->generateDouble() > bp.apical_branch_probability) { // lateral branching

                // determine branch delay if it is larger than 0
                auto hg_paras = static_cast<FungalCellHyphalGrowth*>(mothercell)->getHyphalParameter();
                if (hg_paras->bp.branch_delay > 0){

                    // make sure that branch delay is not negative
                    do{
                        new_branch->bp.branch_delay = mothercell->getSite()->getRandomGenerator()->generateNormalDistributedValue(hg_paras->bp.branch_delay,hg_paras->bp.branch_delay/10);
                    }while(new_branch->bp.branch_delay < 0.0);
                }

                // determine direction randomly
                // TODO: Determine how to handle lateral branching in detail; ADD PARAMETER THAT CONTROLS MEAN ANGLE!
                double random_lateral_angle = mothercell->getSite()->getRandomGenerator()->generateNormalDistributedValue(bp.angle_mean, bp.angle_mean/10);
                if (mothercell->getSite()->getRandomGenerator()->generateDouble() >= 0.5){
                    new_branch->growth_vector_.rotateVectorClockwise(random_lateral_angle);
                }
                else {
                    new_branch->growth_vector_.rotateVectorCounterclockwise(random_lateral_angle);
                }

            }
            else{ // apical branching

                // increase new_direction threshold for main branch
                new_dirction_threshold_ += mothercell->getSite()->getRandomGenerator()->generateNormalDistributedValue(cp.next_curve_mean, 0);

                // give new branch  0 delay
                new_branch->bp.branch_delay = 0.0;
                // define angle between main branch and current growth_vector
                double angle_main = mothercell->getSite()->getRandomGenerator()->generateNormalDistributedValue(bp.angle_mean, bp.angle_std);
                if (mothercell->getSite()->getRandomGenerator()->generateDouble() >= 0.5){
                    angle_main *= -1;
                }
                double angle_new_branch;

                // define angle between main and new branch depending on symmetry
                double symmetric_angle = angle_main/2;
                double assymetric_angle = symmetric_angle + angle_main;

                // Rotate growth vector; random direction is decided by angle_main
                growth_vector_.rotateVectorCounterclockwise(symmetric_angle);

                // decide based on ratio if new branch is symmetric or asymmetric (in relation to growth_vector)
                if (mothercell->getSite()->getRandomGenerator()->generateDouble() < bp.symmetry_probability){
                    angle_new_branch = symmetric_angle;
                    new_branch->growth_vector_.rotateVectorClockwise(angle_new_branch);
                }
                else{
                    angle_new_branch = assymetric_angle;
                    new_branch->growth_vector_.rotateVectorCounterclockwise(angle_new_branch);
                }
            }

            // If the branch that is the origin of the new branch has pierced, set the new branch to be pierced as well
            if (pierced_){
                new_branch->set_Pierced();
                new_branch->set_PierceDistance(lower_surface_->get_distance_from_upper_surface());
            }

            // add branch to branch list of origin branch
            hyphal_branches_.push_back(std::move(new_branch));
            next_branch_threshold_ += mothercell->getSite()->getRandomGenerator()->generateNormalDistributedValue(bp.next_branch_mean, 0);;
        }
    }
    // Call the growth function of all sub-branches
    for (auto &branch: hyphal_branches_) {
        branch->grow(timestep, current_time);
    }
}

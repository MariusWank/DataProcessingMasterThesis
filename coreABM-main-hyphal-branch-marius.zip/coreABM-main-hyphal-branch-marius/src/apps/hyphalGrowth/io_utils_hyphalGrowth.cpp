//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#include <optional>
#include <random>

#include "io_utils_hyphalGrowth.h"
#include "external/json.hpp"
#include "core/utils/macros.h"

using json = nlohmann::json;

abm::util::SimulationParameters abm::utilHyphalGrowth::getSimulationParameters(const std::string &config_path, const std::string &output_path, std::string sid){
    // Load parameters with base abm::utils
    const auto simulator_config = static_cast<boost::filesystem::path>(config_path).append("simulator-config.json").string();
    const auto visualizer_config = static_cast<boost::filesystem::path>(config_path).append("visualisation-config.json").string();

    auto simp = abm::util::getSimulationParameters(simulator_config);
    auto visp = abm::util::getViualizerParameters(visualizer_config);

    std::ifstream json_file(simulator_config);
    json json_parameters;
    json_file >> json_parameters;
    
    const auto hg_config = static_cast<boost::filesystem::path>(config_path).append("hyphal-growth.json").string();
    // Load file again to load hyphalGrowth specific parameters
    std::ifstream json_file_hg(hg_config);
    json hg_para;
    json_file_hg >> hg_para;

    // write hyphalGrowth specific parameters into program
    for (auto &agent: simp.site_parameters->agent_manager_parameters.agents) {
        auto agent_type_ = "FungalCellHyphalGrowth";
        for (const auto &site: json_parameters["Agent-Based-Framework"]["Sites"]) {
            if (agent->type == agent_type_) {
                auto agent_ = site["AgentManager"]["Agents"].at(std::string(agent_type_));
                auto fge = FungalParametersHyphalGrowth{*agent};
                fge.hyphal_growth = agent_.value("hyphal_growth", true);
                if (fge.hyphal_growth) {
                    fge.next_hyphae_rate = hg_para["hyphal-growth"]["hyphal_growth_general"].value("next_hyphae_rate", 0.001);
                    fge.pierce_rate = hg_para["hyphal-growth"]["hyphal_growth_general"].value("pierce_rate", 0.001);
                    fge.evasion = hg_para["hyphal-growth"]["hyphal_growth_general"].value("evasion", 0.001);
                    bool micro_transfer = hg_para["hyphal-growth"]["hyphal_growth_general"].value("include_microscopic_style_transfer", false);
                    if (!micro_transfer) visp.path_style_transfer = "";
                    fge.cp.next_curve_mean = hg_para["hyphal-growth"]["curvature"].value("next_curve_mean", 1.0);
                    fge.cp.angle_mean = hg_para["hyphal-growth"]["curvature"].value("angle_mean", 0.12);
                    fge.bp.next_branch_mean = hg_para["hyphal-growth"]["branching"].value("next_branch_mean", 50.0);
                    fge.bp.angle_mean = hg_para["hyphal-growth"]["branching"].value("angle_mean", 86.89);
                    fge.bp.angle_std = hg_para["hyphal-growth"]["branching"].value("angle_std", 32.68);
                    fge.bp.depth_dependency = hg_para["hyphal-growth"]["branching"].value("depth_dependency", 10.0);
                    fge.bp.branch_delay = hg_para["hyphal-growth"]["branching"].value("branch_delay", 0.0);
                    fge.bp.apical_branch_probability = hg_para["hyphal-growth"]["branching"].value("apical_branch_probability", 0.5);
                    fge.bp.symmetry_probability = hg_para["hyphal-growth"]["branching"].value("symmetry_probability", 0.8);
                    fge.gp.k1 = hg_para["hyphal-growth"]["growth"].value("k1", 4.8);
                    fge.gp.k2 = hg_para["hyphal-growth"]["growth"].value("k2", 1.2);
                    fge.gp.sat_length = hg_para["hyphal-growth"]["growth"].value("sat_length", 5.0);
                }
                agent = std::make_shared<FungalParametersHyphalGrowth>(fge);
            }
        }
    }
    simp.visualizer_to_overwrite = visp;

    return std::move(simp);
};
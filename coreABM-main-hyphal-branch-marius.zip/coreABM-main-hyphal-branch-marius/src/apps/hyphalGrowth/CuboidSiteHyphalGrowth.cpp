//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#include "CuboidSiteHyphalGrowth.h"

#include <utility>
#include "core/simulation/neighbourhood/BalloonListNHLocator.h"
#include "core/simulation/neighbourhood/NeighbourhoodLocator.h"
#include "core/simulation/factories/CellFactory.h"
#include "core/simulation/AgentManager.h"
#include "io_utils_hyphalGrowth.h"
#include "CellFactoryHyphalGrowth.h"
#include "external/json.hpp"
#include "core/utils/macros.h"

using json = nlohmann::json;

CuboidSiteHyphalGrowth::CuboidSiteHyphalGrowth(Randomizer* random_generator,
                       std::shared_ptr<InSituMeasurements> measurements,
                       std::string config_path,
                       std::unordered_map<std::string, std::string> cmd_input_args,
                       std::string output_path)
                       : Site(random_generator, std::move(measurements), config_path,  cmd_input_args, output_path) {

    SYSTEM_STDOUT("Initialize CuboidSiteHyphalGrowth ...");
    auto sid = cmd_input_args.find("sid") != cmd_input_args.end() ? cmd_input_args.find("sid")->second : "";
    parameters_ = abm::utilHyphalGrowth::getSimulationParameters(config_path, output_path, sid);

    // Read in input parameters
    const auto input_config = static_cast<boost::filesystem::path>(config_path).append("input-config.json");
    const auto visualization_config = static_cast<boost::filesystem::path>(config_path).append("visualisation-config.json");
    input_parameters_ = abm::util::getInputParameters(input_config.string());
    visualization_parameters_ = abm::util::getViualizerParameters(visualization_config.string());

    // Read in cmd input and screening parameters
    parameters_.cmd_input_args = cmd_input_args;
    handleCmdInputArgs(cmd_input_args);

    // Read parameters from frontend if frontend-api.json exists
    receiveFrontendParameter(parameters_, input_parameters_, config_path, output_path, sid);

    // Initialize factories
    interaction_factory_ = std::make_unique<InteractionFactory>(parameters_.interaction_parameters, parameters_.use_interactions);
    rate_factory_ = std::make_unique<RateFactory>(input_parameters_.rates);
    cell_factory_ = std::make_unique<CellFactoryHyphalGrowth>(parameters_.site_parameters);
    cell_state_factory_ = std::make_unique<CellStateFactory>(parameters_.site_parameters, rate_factory_.get());
    interaction_state_factory_ = std::make_unique<InteractionStateFactory>(parameters_.interaction_parameters, rate_factory_.get());
    agent_manager_ = std::make_unique<AgentManager>(parameters_, this);

    dimensions = parameters_.dimensions;
    env_surface_ = std::make_unique<Surface>(parameters_.site_parameters->surface, parameters_.site_parameters->x_range, parameters_.site_parameters->y_range, parameters_.site_parameters->z_range, parameters_.site_parameters->grid_step_size, parameters_.site_parameters->interpolation_type);
    lower_env_surface_ = std::make_unique<Surface>(parameters_.site_parameters->surface, parameters_.site_parameters->x_range, parameters_.site_parameters->y_range, parameters_.site_parameters->z_range, parameters_.site_parameters->grid_step_size, parameters_.site_parameters->interpolation_type, parameters_.site_parameters->upper_lower_distance);
    setStoppingCondition(parameters_.stopping_criteria);

    auto* cuboid_parameters = static_cast<abm::util::SimulationParameters::CuboidSiteParameters*>(parameters_.site_parameters.get());
    identifier_ = cuboid_parameters->identifier;
    upper_bound_ = cuboid_parameters->upper_bound;
    lower_bound_ = cuboid_parameters->lower_bound;
    molecules_grid_size_ = cuboid_parameters->molecules_grid_size;
    boundary_type_ = cuboid_parameters->boundary_condition;
    setBoundaryCondition();
    neighbourhood_locator_ = std::make_unique<BalloonListNHLocator>(cuboid_parameters->agent_manager_parameters.agents, lower_bound_, upper_bound_, this);
    initializeAgents(cuboid_parameters->agent_manager_parameters, 0, parameters_.time_stepping);
    agent_manager_->setInitFungalQuantity();
}

bool CuboidSiteHyphalGrowth::containsPosition(Coordinate3D position) {
    bool contains = (position.x >= lower_bound_.x) && (position.x <= upper_bound_.x) &&
                    (position.y >= lower_bound_.y) && (position.y <= upper_bound_.y) &&
                    (position.z >= lower_bound_.z) && (position.z <= upper_bound_.z);

    return contains;
}

Coordinate3D CuboidSiteHyphalGrowth::getRandomPosition() {

    double   x = random_generator_->generateDouble(lower_bound_.x, upper_bound_.x);
    double   y = random_generator_->generateDouble(lower_bound_.y, upper_bound_.y);
    double   z = random_generator_->generateDouble(lower_bound_.z, upper_bound_.z);
    return Coordinate3D{x, y, z};
}

void CuboidSiteHyphalGrowth::handleBoundaryCross(Agent* agent, Coordinate3D* move_vec, double current_time) {

    boundary_condition_->handleBoundaryCross(agent, move_vec, current_time);
}

Coordinate3D CuboidSiteHyphalGrowth::getLowerLimits() {
    return lower_bound_;
}

Coordinate3D CuboidSiteHyphalGrowth::getUpperLimits() {
    return upper_bound_;
}

Coordinate3D CuboidSiteHyphalGrowth::getRandomBoundaryPoint() {
    double x, y, z;
    double ylength, xlength;
    double xProb;

    double xyArea, xzArea, yzArea, totalArea;
    double xyProb, xzProb;

    double rand;
    unsigned int use_lower_bound_;

    xyArea = fabs((upper_bound_.y - lower_bound_.y) * (upper_bound_.x - lower_bound_.x));
    xzArea = fabs((upper_bound_.x - lower_bound_.x) * (upper_bound_.z - lower_bound_.z));
    yzArea = fabs((upper_bound_.y - lower_bound_.y) * (upper_bound_.z - lower_bound_.z));

    totalArea = xyArea + xzArea + yzArea;

    xyProb = xyArea / totalArea;
    xzProb = xzArea / totalArea;

    rand = random_generator_->generateDouble();
    use_lower_bound_ = random_generator_->generateInt(1);
    if (rand < xyProb) {
        //place point in xyPlane
        if (use_lower_bound_) {
            x = random_generator_->generateDouble(lower_bound_.x, upper_bound_.x);
            y = random_generator_->generateDouble(lower_bound_.y, upper_bound_.y);
            z = lower_bound_.z;
        } else {
            x = random_generator_->generateDouble(lower_bound_.x, upper_bound_.x);
            y = random_generator_->generateDouble(lower_bound_.y, upper_bound_.y);
            z = upper_bound_.z;
        }
    } else {
        if (rand < xyProb + xzProb) {
            //place point in xzPlane
            if (use_lower_bound_) {
                x = random_generator_->generateDouble(lower_bound_.x, upper_bound_.x);
                y = lower_bound_.y;
                z = random_generator_->generateDouble(lower_bound_.z, upper_bound_.z);
            } else {
                x = random_generator_->generateDouble(lower_bound_.x, upper_bound_.x);
                y = upper_bound_.y;
                z = random_generator_->generateDouble(lower_bound_.z, upper_bound_.z);
            }
        } else {
            //place point in yzPlane
            if (use_lower_bound_) {
                x = lower_bound_.x;
                y = random_generator_->generateDouble(lower_bound_.y, upper_bound_.y);
                z = random_generator_->generateDouble(lower_bound_.z, upper_bound_.z);
            } else {
                x = upper_bound_.x;
                y = random_generator_->generateDouble(lower_bound_.y, upper_bound_.y);
                z = random_generator_->generateDouble(lower_bound_.z, upper_bound_.z);
            }
        }
    }


    if (dimensions == 2) {
        z = (upper_bound_.z + lower_bound_.z)/2;
    }
    Coordinate3D nextPos = Coordinate3D();
    Coordinate3D boundaryPoint = Coordinate3D{x, y, z};

    do {
        boundary_input_vector_ = generateRandomDirectionVector(boundaryPoint, 1);
        nextPos = boundaryPoint;
        nextPos += boundary_input_vector_;
    } while (!containsPosition(nextPos));

    return Coordinate3D{x, y, z};
}

Coordinate3D CuboidSiteHyphalGrowth::generateRandomDirectionVector(Coordinate3D position, double length) {

    //get a sin() sampled value in [0,PI] for theta via a uniform value of u
    if (dimensions == 2) {
        double phi = random_generator_->generateDouble(M_PI * 2.0);
        double x = length * cos(phi);
        double y = length * sin(phi);
        double z = 0;
        return Coordinate3D{x, y, z};
    } else if (dimensions == 3) {
        double u = random_generator_->generateDouble(); //sampler->sample();

        double phi = random_generator_->generateDouble(M_PI * 2.0);
        double r = length;

        double subst = 2 * r * sqrt(u * (1 - u));
        double x = subst * cos(phi);
        double y = subst * sin(phi);
        double z = r * (1 - 2 * u);
        return Coordinate3D{x, y, z};
    } else {
        return Coordinate3D{};
    }
}

Coordinate3D CuboidSiteHyphalGrowth::generatePersistentDirectionVector(Coordinate3D position,
                                                           double length,
                                                           Coordinate3D prevVector,
                                                           double previousAlpha) {
    if (prevVector.getMagnitude() == 0){
        prevVector *= 0;
    }
    else {
        prevVector *= length/prevVector.getMagnitude();
    }
    return prevVector;
}

Coordinate3D CuboidSiteHyphalGrowth::generateBackShiftOnContacting(SphereRepresentation* activeSphere, SphereRepresentation* passiveSphere, double mustOverhead) {

    Coordinate3D normalVecBetwCells = activeSphere->getEffectiveConnection(passiveSphere);
    double overlap = passiveSphere->getRadius() + activeSphere->getRadius() - normalVecBetwCells.getMagnitude();

    Coordinate3D backShift = normalVecBetwCells;
    if (overlap > 0 && backShift.getMagnitude() !=0 ) {
        backShift *= -(overlap - mustOverhead)/backShift.getMagnitude();
    } else {
        backShift *=0;
    }

    return backShift;
}

void CuboidSiteHyphalGrowth::handleCmdInputArgs(std::unordered_map<std::string, std::string>cmd_input_args) {
    // Parameters to be screened or from cmd input
    // You can add your parameters you wanna screen below here
    if (cmd_input_args.size() > 0) {
        for (const auto &agent: parameters_.site_parameters->agent_manager_parameters.agents) {
            if (abm::util::isSubstring("ImmuneCell", agent->type)) {
                for (const auto &[key, value]: cmd_input_args) {
                    if ("icNum" == key) {
                        agent->number = std::stod(value);
                    }
                }
            }
            if (abm::util::isSubstring("FungalCell", agent->type)) {
                auto *fc_parameters = static_cast<abm::utilHyphalGrowth::FungalParametersHyphalGrowth*>(agent.get());
                for (const auto &[key, value]: cmd_input_args) {
                    if ("fcNum" == key) {
                        fc_parameters->number = std::stoi(value);
                    } else if ("bAng" == key) {
                        fc_parameters->bp.angle_mean = std::stod(value);
                    } else if ("bLen" == key) {
                        fc_parameters->bp.next_branch_mean = std::stod(value);
                    } else if ("rad" == key) {
                        fc_parameters->morphology_parameters.radius = std::stod(value);
                    } else if ("cAng" == key) {
                        fc_parameters->cp.angle_mean = std::stod(value);
                    }else if ("cLen" == key) {
                        fc_parameters->cp.next_curve_mean = std::stod(value);
                    }else if ("bDD" == key) {
                        fc_parameters->bp.depth_dependency = std::stod(value);
                    }else if ("bDelay" == key) {
                        fc_parameters->bp.branch_delay = std::stod(value);
                    }else if ("pA" == key) {
                        fc_parameters->bp.apical_branch_probability = std::stod(value);
                    }else if ("pSym" == key) {
                        fc_parameters->bp.symmetry_probability = std::stod(value);
                    }else if ("k1" == key) {
                        fc_parameters->gp.k1 = std::stod(value);
                    }else if ("k2" == key) {
                        fc_parameters->gp.k2 = std::stod(value);
                    }else if ("sat_length" == key) {
                        fc_parameters->gp.sat_length = std::stod(value);
                    }else if ("pR" == key) {
                        fc_parameters->pierce_rate = std::stod(value);
                    }else if ("eva" == key) {
                        fc_parameters->evasion = std::stod(value);
                    }
                }
            }
        }
    }
}

void CuboidSiteHyphalGrowth::receiveFrontendParameter(abm::util::SimulationParameters &sim_para, abm::util::InputParameters &inp_para,
                                    const std::string &config_path, const std::string &output_path, std::string sid) {
    const auto simulator_config = static_cast<boost::filesystem::path>(config_path).append("simulator-config.json").string();
    const auto visualizer_config = static_cast<boost::filesystem::path>(config_path).append("visualisation-config.json").string();

    auto visp = abm::util::getViualizerParameters(visualizer_config);

    std::ifstream json_file(simulator_config);
    json json_parameters;
    json_file >> json_parameters;

    const auto hg_config = static_cast<boost::filesystem::path>(output_path).append("frontend-api"+sid+".json").string();
    // Load file again to load hyphalGrowth specific parameters

    if (boost::filesystem::exists(hg_config) && sid != "") {
        std::ifstream json_file_hg(hg_config);
        json hg_para;
        json_file_hg >> hg_para;

        sim_para.max_time = hg_para["frontend-api"]["simulation_parameter"]["max_time"].value("value", 100);
        auto number_images = hg_para["frontend-api"]["simulation_parameter"]["output_images"].value(
                "value", 10);
        if (number_images > 0) {
            visp.output_interval = int(sim_para.max_time / (number_images * sim_para.time_stepping));
        } else {
            visp.pov_active = false;
        }
        visp.output_video = false; // important for the frontend, this must be false
        bool micro_transfer = hg_para["frontend-api"]["simulation_parameter"]["include_microscopic_style_transfer"].value(
                "value", false);
        if (!micro_transfer or !visp.pov_active) visp.path_style_transfer = "";

        sim_para.dimensions = int(hg_para["frontend-api"]["simulation_parameter"]["dimensions"].value("value", 2));
        sim_para.site_parameters->surface = "plane";

        if (sim_para.dimensions == 3) {
            visp.camera_position = Coordinate3D{0, -visp.camera_position.z, visp.camera_position.z/3};
                    //Coordinate3D{-visp.camera_position.z, visp.camera_position.z/4, visp.camera_position.z/2};
            sim_para.site_parameters->surface = hg_para["frontend-api"]["simulation_parameter"]["surface"].value("value", "plane");
            visp.path_style_transfer = "";
            if (sim_para.site_parameters->type == "CuboidSite") {
                auto* cuboid_parameters = static_cast<abm::util::SimulationParameters::CuboidSiteParameters*>(sim_para.site_parameters.get());
                std::cout << "new site para: " << cuboid_parameters->upper_bound.printCoordinates() << " - " << cuboid_parameters->lower_bound.printCoordinates() << "\n";
                cuboid_parameters->upper_bound.z = (cuboid_parameters->upper_bound.x + cuboid_parameters->upper_bound.y)/2;
                cuboid_parameters->lower_bound.z = (cuboid_parameters->lower_bound.x + cuboid_parameters->lower_bound.y)/4;
            }
        }

        // write hyphalGrowth specific parameters into program
        for (auto &agent: sim_para.site_parameters->agent_manager_parameters.agents) {
            auto agent_type_ = "FungalCellHyphalGrowth";
            for (const auto &site: json_parameters["Agent-Based-Framework"]["Sites"]) {
                if (agent->type == agent_type_) {
                    auto agent_ = site["AgentManager"]["Agents"].at(std::string(agent_type_));
                    auto fge = abm::utilHyphalGrowth::FungalParametersHyphalGrowth{*agent};
                    fge.hyphal_growth = agent_.value("hyphal_growth", true);
                    if (fge.hyphal_growth) {
                        bool diff_colors = hg_para["frontend-api"]["hyphal_growth_general"]["use_different_colors"].value(
                                "value", false);
                        fge.morphology_parameters.color = diff_colors ? "random" : "darkGreen";
                        fge.number = hg_para["frontend-api"]["hyphal_growth_general"]["number_initial_cells"].value(
                                "value", 10);
                        fge.morphology_parameters.radius = hg_para["frontend-api"]["hyphal_growth_general"]["fungus_radius"].value(
                                "value", 1.25);
                        fge.next_hyphae_rate = hg_para["frontend-api"]["hyphal_growth_general"]["next_hyphae_rate"].value(
                                "value", 0.001);
                        fge.pierce_rate = hg_para["frontend-api"]["hyphal_growth_general"]["pierce_rate"].value(
                            "value", 0.0);
                        fge.evasion = hg_para["frontend-api"]["hyphal_growth_general"]["evasion"].value(
                            "value", 0);
                        fge.cp.next_curve_mean = hg_para["frontend-api"]["curvature"]["next_curve_mean"].value("value",
                                                                                                               1.0);
                        fge.cp.angle_mean = hg_para["frontend-api"]["curvature"]["angle_mean"].value("value", 0.12);
                        fge.bp.next_branch_mean = hg_para["frontend-api"]["branching"]["next_branch_mean"].value(
                                "value", 1.0);
                        fge.bp.angle_mean = hg_para["frontend-api"]["branching"]["angle_mean"].value("value", 0.12);
                        fge.bp.angle_std = hg_para["frontend-api"]["branching"]["angle_std"].value("value", 0.12);
                        fge.bp.depth_dependency = hg_para["frontend-api"]["branching"]["depth_dependency"].value(
                                "value", 1.0);
                        fge.gp.k1 = hg_para["frontend-api"]["growth"]["k1"].value("value", 4.8);
                        fge.gp.k2 = hg_para["frontend-api"]["growth"]["k2"].value("value", 1.2);
                        fge.gp.sat_length = hg_para["frontend-api"]["growth"]["sat_length"].value("value", 5.0);
                    }
                    agent = std::make_shared<abm::utilHyphalGrowth::FungalParametersHyphalGrowth>(fge);
                }
            }
        }
        sim_para.visualizer_to_overwrite = visp;
    }
}

void CuboidSiteHyphalGrowth::initializeAgents(const abm::util::SimulationParameters::AgentManagerParameters &parameters,
                                  double current_time,
                                  double time_delta) {

    for (const auto &agent_parameters: parameters.agents) {
        const auto init_distribution = agent_parameters->initial_distribution;
        const auto name = agent_parameters->type;
        const auto number_of_agents = agent_parameters->number;
        double z_level = (upper_bound_.z + lower_bound_.z)/2;
        for (auto i = 0; i < number_of_agents; ++i) {
            Coordinate3D initial_position = env_surface_->surfacePoint(getRandomPosition());
            // such that first agent is initialized in the center
            if (i == 0) {initial_position = {0.0, 0.0, 0.0};}
            Coordinate3D initial_vector = Coordinate3D();
            if (dimensions == 2) { initial_position.z = z_level;}

            auto agent = agent_manager_->emplace_back(cell_factory_->createCell(name,
                                                                                std::make_unique<Coordinate3D>(initial_position),
                                                                                agent_manager_->generateNewID(),
                                                                                this,
                                                                                time_delta,
                                                                                current_time));
            if (initial_vector.getMagnitude() != 0) {
                agent->getMovement()->setPreviousMove(&initial_vector);
            }
            if (abm::util::isSubstring("FungalCell", agent->getTypeName())) {
                agent_manager_->addFungalCellToList(agent.get());
            }
        }
    }
}

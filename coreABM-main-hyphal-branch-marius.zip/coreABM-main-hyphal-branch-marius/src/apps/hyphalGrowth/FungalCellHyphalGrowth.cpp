//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.


#include "FungalCellHyphalGrowth.h"
#include "core/simulation/Site.h"
#include "core/simulation/morphology/SphericalMorphology.h"
#include "environment/Surface.h"

#include "core/utils/macros.h"

void FungalCellHyphalGrowth::doMorphologicalChanges(double timestep, double current_time) {

    auto cs = cellState->getStateName();
    hyphal_growth_ = cs == "FungalHyphal" || surface->getBasicSphereOfThis()->getRadius() >= max_radius_;

    /* Only add if swelling becomes relevant again
    if (cs == "FungalSwelling") {
        auto swellFactor = exp(log(max_radius_) / ((swell_duration_) / timestep));
        auto radiusConidia = surface->getBasicSphereOfThis()->getRadius();
        if (radiusConidia < max_radius_) {
            surface->getBasicSphereOfThis()->setRadius(radiusConidia * swellFactor);
        }
    }
     */

    if (hyphal_growth_) {
        if (hyphal_branches_.empty()) {
            hyphal_branches_.emplace_back(std::make_unique<HyphalBranch>(this, position, 0, Coordinate3D{0.0, 0.0, 0.0}));
            DEBUG_STDOUT("Start Hyphal Growth at " + std::to_string(current_time));
        } else {
            auto probability_next_hyphae = rate_next_mothercell_hyphae_ * timestep;
            if (probability_next_hyphae > site->getRandomGenerator()->generateDouble()) {
                hyphal_branches_.emplace_back(std::make_unique<HyphalBranch>(this, position, 0, Coordinate3D{0.0, 0.0, 0.0}));
                DEBUG_STDOUT("New HyphalBranch from ROOT at " + std::to_string(current_time));
            }

            for (auto& branch : hyphal_branches_) {

                // Collect all subbranches
                std::set<HyphalBranch*> all_branches = branch->getAllSubbranches();
                std::vector<HyphalBranch*> all_branches_vector(all_branches.begin(), all_branches.end());
                std::vector<HyphalBranch*> unpierced_branches;

                // Check if branches that haven't pierced are left
                int unpierced_branches_num = 0;
                for (auto* branch : all_branches) {
                    if (!branch->hasPierced()) {
                        unpierced_branches_num += 1;
                        unpierced_branches.emplace_back(branch);
                    }
                }

                // If unpierced branches are left, check if piercing occurs and set random unpierced branch as piercing
                auto pierce_probability = hyphae_pierce_probability_ * timestep;
                if (pierce_probability > site->getRandomGenerator()->generateDouble() && unpierced_branches_num > 0) {
                    int rand_index = site->getRandomGenerator()->generateInt(0, unpierced_branches.size() - 1);
                    unpierced_branches[rand_index]->pierce();
                }
                branch->grow(timestep, current_time);
            }
        }
    }
}

void FungalCellHyphalGrowth::setup(double time_delta, double current_time, abm::util::SimulationParameters::AgentParameters * parameters) {
    fc_parameters_ = static_cast<abm::utilHyphalGrowth::FungalParametersHyphalGrowth * >(parameters);

    max_radius_ = fc_parameters_->morphology_parameters.radius; // add a factor if swelling should become relevant again
    swell_duration_ = 1.0;
    number_of_branches_ = 0;
    rate_next_mothercell_hyphae_ = fc_parameters_->next_hyphae_rate;
    hyphae_pierce_probability_ = fc_parameters_->pierce_rate;

    // Create an object of Surface with the plane surface function
    Cell::setup(time_delta, current_time, parameters);
}
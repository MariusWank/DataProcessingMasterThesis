//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#ifndef CORE_UTILS_IO_UTIL_HyphalGrowth_H
#define CORE_UTILS_IO_UTIL_HyphalGrowth_H

#include <iostream>
#include <string>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <array>
#include <type_traits>

#include <boost/filesystem.hpp>

#include "core/basic/Coordinate3D.h"
#include "core/utils/io_util.h"

namespace abm::utilHyphalGrowth {

    // To create your own parameters, you have to define them here and let them inherit from the base parameter structs
    // In the Site (here: CuboidSiteHyphalGrowth) you must read in abm::utilHyphalGrowth::getSim.. instead of abm::util:getSim..
    // The parameter are set in the in io_util_hyphalGrowth.cpp

    struct curveParameters {
        double angle_mean;
        double next_curve_mean;
    };

    struct branchParameters {
        double angle_mean;
        double angle_std;
        double next_branch_mean;
        double depth_dependency;
        double branch_delay;
        double apical_branch_probability;
        double symmetry_probability;
    };

    struct growthParameter {
        double k1;
        double k2;
        double sat_length;
    };

    struct FungalParametersHyphalGrowth : abm::util::SimulationParameters::FungalParameters {
        bool hyphal_growth{};
        double next_hyphae_rate{};
        double pierce_rate{};
        int evasion{};
        curveParameters cp{};
        branchParameters bp{};
        growthParameter gp{};
    };

    abm::util::SimulationParameters getSimulationParameters(const std::string &config_path, const std::string &output_path, std::string sid="");

}

#endif //CORE_UTILS_IO_UTILS_HyphalGrowth_H

//  Copyright by Christoph Saffer, Paul Rudolph, Sandra Timme, Marco Blickensdorf, Johannes Pollmächer
//  Research Group Applied Systems Biology - Head: Prof. Dr. Marc Thilo Figge
//  https://www.leibniz-hki.de/en/applied-systems-biology.html
//  HKI-Center for Systems Biology of Infection
//  Leibniz Institute for Natural Product Research and Infection Biology - Hans Knöll Insitute (HKI)
//  Adolf-Reichwein-Straße 23, 07745 Jena, Germany
//
//  This code is licensed under BSD 2-Clause
//  See the LICENSE file provided with this code for the full license.

#ifndef COREABM_SURFACE_H
#define COREABM_SURFACE_H

#include "CustomSurface.h"
#include "core/basic/Coordinate3D.h"
#include <cmath>
#include <functional>
#include <memory>
#include <vector>

class Surface {
public:
    Surface(const std::string& surface_type_ ="", std::array<int, 2> x_range={-650, 650}, std::array<int, 2> y_range= {-500, 500}, std::array<float, 2> z_range= {-500, 500}, int step_size=1, const std::string& interpolation_type="bilinear", double z_axis_lowering = 0.0);

    std::pair<Coordinate3D, Coordinate3D> perpendicularVectors(const Coordinate3D& point) const;

    Coordinate3D perpendicularVector(const Coordinate3D& point, const Coordinate3D& tangent1) const;

    Coordinate3D surfacePoint(const Coordinate3D& point) const;

    Coordinate3D surfaceNormal(const Coordinate3D& point) const;

    size_t findClosestPointIndex(const std::vector<Coordinate3D>& points, const Coordinate3D& target) const;

    const CustomSurface& getCustomSurface() const {
        return *custom_surface_;
    }

    std::string getSurfaceType() const{return surface_type_;};

    std::array<int, 2> getXRange() const{return x_range_;};

    std::array<int, 2> getYRange() const{return y_range_;};

    std::array<float, 2> getZRange() const{return z_range_;};

    double get_distance_from_upper_surface() const{return fabs(z_axis_lowering_);};

private:
    std::vector<Coordinate3D> surface_points_;
    std::function<Coordinate3D(const Coordinate3D&)> surface_function_;
    std::function<Coordinate3D(const Coordinate3D&)> surface_normal_;
    std::unique_ptr<CustomSurface> custom_surface_;
    std::string surface_type_;
    std::array<int, 2>x_range_{};
    std::array<int, 2>y_range_{};
    std::array<float, 2>z_range_{};
    double z_axis_lowering_;
};


#endif //COREABM_SURFACE_H

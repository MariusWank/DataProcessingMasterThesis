// Triangulation.h
#pragma once

#include "core/basic/Coordinate3D.h"
#include <cmath>
#include <functional>
#include <memory>
#include <vector>

class CustomSurface {
  public:
    explicit CustomSurface(const std::string& type = "randomSurface", std::array<int, 2> x_range = {-650, 650}, std::array<int, 2> y_range = {-500, 500}, int step_size = 1, std::string interpolation_type = "bilinear", double z_axis_lowering =0.0);

    // Function to calculate the gradient at a specific point on the surface
    Coordinate3D calculateGradient(Coordinate3D queryPoint);

    double z_Interpolation(Coordinate3D queryPoint);

    double gaussianRBF(double distance);

    const std::vector<std::vector<Coordinate3D>>& getGrid() const{return grid_;};

    const std::vector<std::vector<std::array<double, 16>>>& get_a_ij_matrix() const{return a_ij_matrix_;};

    const std::vector<int> getDimensions() const{return {number_of_rows_, number_of_columns_};};

    const int getStepSize() const{return step_size_;};

    const std::string getInterpolationType() const{return interpolation_type_;};

    std::array<float, 2> getZRange(){return z_range_;};
    std::array<int, 2> getXRange(){return x_range_;};
    std::array<int, 2> getYRange(){return y_range_;};

    std::pair<double, double> calculateCurvatures(Coordinate3D queryPoint);

    static std::array<std::array<double, 3>, 3> matrixSubtraction(std::array<std::array<double, 3>, 3> matrix1, std::array<std::array<double, 3>, 3> matrix2);

    static std::array<std::array<double, 3>, 3> vectorMultiplication(std::array<double, 3> vector1, std::array<double, 3> vector2);

    static std::array<std::array<double, 3>, 3> matrixMultiplication(std::array<std::array<double, 3>, 3> matrix1, std::array<std::array<double, 3>, 3> matrix2);

    static double sumOfMatrix(std::array<std::array<double, 3>, 3> matrix);

    double calculateMagnitude(std::array<double, 3> vector);

    static std::array<std::array<double, 3>, 3> addFactorToMatrixValues(std::array<std::array<double, 3>, 3> matrix, double factor);

    std::array<std::array<double, 3>, 3> calculateHessianMatrix(Coordinate3D queryPoint);

    std::array<double, 16> construct_aij_vector(int grid_index_i, int grid_index_j);

    std::array<double, 16> matrixVectorMultiplication(std::array<std::array<int, 16>, 16> matrix, std::array<double, 16> vector);

    double power(double base, int exponent);

  private:
    std::vector<std::vector<Coordinate3D>> grid_;
    std::vector<std::vector<std::array<double, 16>>> a_ij_matrix_;
    std::array<std::array<int, 16>, 16> inverse_matrix_A_ = {};
    std::array<int, 2> x_range_{};
    std::array<int, 2> y_range_{};
    std::array<float, 2> z_range_{};
    int step_size_ {};
    int number_of_columns_;
    int number_of_rows_;
    std::string interpolation_type_;
    double z_axis_lowering_;
};


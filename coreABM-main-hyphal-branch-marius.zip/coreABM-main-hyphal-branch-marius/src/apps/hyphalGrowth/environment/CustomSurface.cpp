#include "CustomSurface.h"

#include "core/utils/macros.h"
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/split.hpp>
#include <fstream>
#include <iostream>
#include <math.h>
#include <random>
#include <set>
#include <sstream>
#include <utility>

CustomSurface::CustomSurface(const std::string& type, std::array<int, 2> x_range, std::array<int, 2> y_range, int step_size, std::string interpolation_type, double z_axis_lowering)
    :interpolation_type_(std::move(interpolation_type)), step_size_(step_size), x_range_(x_range), y_range_(y_range), z_axis_lowering_(z_axis_lowering){

    // Declare projection variables to project index to grid position i.e. (0,0) -> (-650, -500)
    float projected_x = NAN;
    float projected_y = NAN;

    // Create random grid if type is set to randomSurface
    if (type == "randomSurface") {

        // Define member variables according to config data
        z_range_[0] = -1.0F - z_axis_lowering_;
        z_range_[1] = z_range_[0] + 2.0F - z_axis_lowering_;
        number_of_rows_ = static_cast<int>((x_range_[1] - x_range_[0]) / step_size_) + 1;
        number_of_columns_ = static_cast<int>((y_range_[1] - y_range_[0]) /step_size_) + 1;

        std::random_device dev;
        std::mt19937 rng(1); // change seed to dev() if a new random surface should be generated everytime the program runs
        std::uniform_int_distribution<std::mt19937::result_type> dist(0,RAND_MAX); // distribution in range [0, RAND_MAX]

        // Resize the grid to the required dimensions
        grid_.resize(number_of_rows_, std::vector<Coordinate3D>(number_of_columns_));

        // Construct grid
        for (int i = 0; i < number_of_rows_; i++) {
            for (int j = 0; j < number_of_columns_; j++) {
                projected_x = x_range_[0] + i * step_size_;
                projected_y = y_range_[0] + j * step_size_;
                if (projected_x == 0 && projected_y == 0) { // ensure that first conidia lies on (0, 0, 0)
                    grid_[i][j] = {projected_x, projected_y, 0.0 - z_axis_lowering_};
                } else {
                    grid_[i][j] = {projected_x, projected_y, z_range_[0] + (static_cast<float>(dist(rng)) / static_cast<float>(RAND_MAX)) * static_cast<float>(2)};
                }
            }
        }
    }

    // Read csv file if its path is specified
    else if (type.find(".csv") != std::string::npos){

        // declare variables
        std::string buffer;
        std::vector<std::string> results;
        std::vector<float> x_values, y_values, z_values;
        float x_value, y_value, z_value;
        float base_level = 0;

        // Create buffer string
        std::ifstream  file(type);
        std::string line;

        std::getline(file, line); //skip first line as it contains descriptions

        // Iterate lines of file and get relevant data
        while (std::getline(file, line)){

            // get line and split string via delimiter
            std::istringstream ss(line);
            ss >> buffer;
            boost::split(results, buffer, boost::is_any_of(","));

            // save relevant values
            x_value = std::stof(results[1]);
            y_value = std::stof(results[2]);
            z_value = std::stof(results[3]);

            // Only add values if the coordinates lie on uniform grid
            if (static_cast<int>(x_value) == x_value && static_cast<int>(y_value) == y_value &&
                abs(static_cast<int>(x_value))%step_size_ == 0 && abs(static_cast<int>(y_value))%step_size_ == 0 &&
                x_value <= x_range[1] && x_value >= x_range[0] && y_value <= y_range[1] && y_value >= y_range[0]){ // only add values that lie on uniform grid defined by config
                x_values.push_back(x_value);
                y_values.push_back(y_value);
                z_values.push_back(z_value);
            }

            // Get height of surface at (0,0) to correct surface level
            if (x_value == 0 && y_value == 0){
                base_level = z_value;
            }
        }

        // Correct height of surface so that (0, 0, 0) lies on the surface
        std::for_each(z_values.begin(), z_values.end(), [&base_level](float &n) { n -= base_level; });

        // Define member variables depending on custom data
        step_size_ = step_size;
        z_range_[0] = *std::min_element(z_values.begin(), z_values.end()) - z_axis_lowering_;
        z_range_[1] = *std::max_element(z_values.begin(), z_values.end()) - z_axis_lowering_;
        number_of_rows_ = static_cast<int>((x_range_[1] - x_range_[0]) / step_size_) + 1;
        number_of_columns_ = static_cast<int>((y_range_[1] - y_range_[0]) /step_size_) + 1;

        // Resize the grid to the required dimensions
        grid_.resize(number_of_rows_, std::vector<Coordinate3D>(number_of_columns_));

        // Construct grid according to variables defined by custom data
        for (int i = 0; i < number_of_rows_; i++) {
            #pragma unroll (5)
            for (int j = 0; j < number_of_columns_; j++) {
                grid_[i][j] = {x_values[i*number_of_columns_+j], y_values[i*number_of_columns_+j], z_values[i*number_of_columns_+j] - z_axis_lowering_};
            }
        }
    }

    // Create aij_matrix if interpolation type is set to bicubic
    if (interpolation_type_ == "bicubic"){

        // Define inverse matrix A⁻¹ (a constant matrix that results from the linear equation system of the calculation)
        inverse_matrix_A_ = {{
            {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0},
            {-3,3,0,0,-2,-1,0,0,0,0,0,0,0,0,0,0},
            {2,-2,0,0,1,1,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0},
            {0,0,0,0,0,0,0,0,-3,3,0,0,-2,-1,0,0},
            {0,0,0,0,0,0,0,0,2,-2,0,0,1,1,0,0},
            {-3,0,3,0,0,0,0,0,-2,0,-1,0,0,0,0,0},
            {0,0,0,0,-3,0,3,0,0,0,0,0,-2,0,-1,0},
            {9,-9,-9,9,6,3,-6,-3,6,-6,3,-3,4,2,2,1},
            {-6,6,6,-6,-3,-3,3,3,-4,4,-2,2,-2,-2,-1,-1},
            {2,0,-2,0,0,0,0,0,1,0,1,0,0,0,0,0},
            {0,0,0,0,2,0,-2,0,0,0,0,0,1,0,1,0},
            {-6,6,6,-6,-4,-2,4,2,-3,3,-3,3,-2,-1,-2,-1},
            {4,-4,-4,4,2,2,-2,-2,2,-2,2,-2,1,1,1,1}
        }};

        // Construct matrix that contains a_ij values for every cell defined by four corner points
        a_ij_matrix_.resize(number_of_rows_ - 1, std::vector<std::array<double, 16>>(number_of_columns_ - 1));
        for (int i = 0; i < number_of_rows_-1; i++) {
            for (int j = 0; j < number_of_columns_ - 1; j++) {
                a_ij_matrix_[i][j] = construct_aij_vector(i, j);
            }
        }
    }
}

// Bilinear interpolation function
double CustomSurface::z_Interpolation(Coordinate3D queryPoint) {

    // Create default value
    double z = 0.0;

    // Get corresponding grid entry for query Point
    // case if queryPoint lies outside the environment -> pad with value of closest point
    if (queryPoint.x > x_range_[1] || queryPoint.x < x_range_[0] || queryPoint.y > y_range_[1] || queryPoint.y < y_range_[0]){
        return queryPoint.z;
    }

    // projection of queryPoint to top left corner point of corresponding cell
    int i = static_cast<int>((queryPoint.x + abs(x_range_[0])) / step_size_);
    int j = static_cast<int>((queryPoint.y + abs(y_range_[0])) / step_size_);

    // catch if queryPoint lies on right most column -> change projection
    if (j == number_of_columns_-1){
        j -= 1;
    }

    // catch if queryPoint lies on bottom most row -> change projection
    if (i == number_of_rows_-1){
        i -= 1;
    }

    // If interpolation is bilinear
    if (interpolation_type_ == "bilinear"){

        // case if queryPoint lies on discrete grid point -> return grid value
        if (static_cast<int>(queryPoint.x) == queryPoint.x && static_cast<int>(queryPoint.y) == queryPoint.y &&
            abs(static_cast<int>(queryPoint.x))%step_size_ == 0 && abs(static_cast<int>(queryPoint.y))%step_size_ == 0){
            return grid_[i][j].z;
        }

        // Define four cornerpoints of cell
        Coordinate3D f00 = grid_[i][j+1];
        Coordinate3D f01 = grid_[i][j];
        Coordinate3D f10 = grid_[i+1][j+1];
        Coordinate3D f11 = grid_[i+1][j];

        // Calculate relevant numbers for interpolation
        double x_scale_right = (f10.x - queryPoint.x) / (f10.x - f00.x);
        double x_scale_left = (queryPoint.x - f00.x) / (f10.x - f00.x);
        double y_scale_top = (f00.y - queryPoint.y) / (f00.y - f01.y);
        double y_scale_bot = (queryPoint.y - f01.y) / (f00.y - f01.y);

        double fx1_z = x_scale_right * f00.z + x_scale_left * f10.z;
        double fx2_z = x_scale_right * f01.z + x_scale_left * f11.z;

        // Save interpolated z value
        z = y_scale_bot * fx1_z + y_scale_top * fx2_z;
    }

    // if interpolation type is radial
    else if (interpolation_type_ == "radial"){

        // define some releavant variables
        double sumRadial = 0.0;
        double distance = 0.0;

        // Select cutoff to save runtime
        int cutoff = 5; // cutoff necessary to reduce runtime; after a distance of 5 the RBF becomes almost 0 and therefore doesn't influence the interpolation anymore.
        int minX = std::max(0, i - cutoff);
        int maxX = std::min(i + cutoff, number_of_rows_);
        int minY = std::max(0, j - cutoff);
        int maxY = std::min(j + cutoff, number_of_columns_);

        // Iterate all points within cutoff
        for (int u = minX; u < maxX; ++u) {
            for (int v = minY; v < maxY; ++v) {
                distance = queryPoint.calculateEuclidianDistanceWithoutZ(grid_[u][v]);
                z += grid_[u][v].z * gaussianRBF(distance); // instead of using the function value at the coordinate as a weight, a LES could be solved to determine weights in a way that grid points have their actual function value instead an interpolated one
                sumRadial += gaussianRBF(distance);
            }
        }
        // Normalization
        z /= sumRadial;
    }

    // if interpolation type is bicubic
    else if (interpolation_type_ == "bicubic"){

        // assign a_ij vecor that corresponds to cell where query_point lies
        std::array<double, 16> a_ij_vector = a_ij_matrix_[i][j];

        // normalize coordinate so that they lie between 0 and 1 (0,0 would be top left corner and 1,1 bottom right)
        double x_min = grid_[i][j].x;
        double x_max = grid_[i+1][j+1].x;
        double y_min = grid_[i][j].y;
        double y_max = grid_[i+1][j+1].y;
        double normalized_x = ((queryPoint.x - x_min) / (x_max - x_min));
        double normalized_y = ((queryPoint.y - y_min) / (y_max - y_min));

        // calculate z_value using bicubic interpolation function
        for (int u = 0; u < 4; u++){
            for (int v = 0; v < 4; v++){
                z += a_ij_vector[4*v+u] * power(normalized_x, u) * power(normalized_y, v); // custom power functions to support 0⁰ == 1
            }
        }
    }
    // if no valid interpolation type is provided
    else {
        std::cout << "No valid interpolation type was selected!\n";
        return NAN;
    }
    return z;
}

// Function to calculate the gradient at a given position according to finite difference
Coordinate3D CustomSurface::calculateGradient(Coordinate3D queryPoint) {

    double epsilon = 1e-5; // Select small epsilon for better results

    // Calculate gradient using interpolation
    const Coordinate3D x_plus = {queryPoint.x + epsilon, queryPoint.y, queryPoint.z};
    const Coordinate3D y_plus = {queryPoint.x, queryPoint.y + epsilon, queryPoint.z};
    const Coordinate3D x_minus = {queryPoint.x - epsilon, queryPoint.y, queryPoint.z};
    const Coordinate3D y_minus = {queryPoint.x, queryPoint.y - epsilon, queryPoint.z};
    double gradX = (z_Interpolation(x_plus) - z_Interpolation(x_minus))/ (2*epsilon);
    double gradY = (z_Interpolation(y_plus) - z_Interpolation(y_minus))/ (2*epsilon);

    return Coordinate3D{gradX, gradY, -1.0};
}

// RBF for radial interpolation
double CustomSurface::gaussianRBF(double distance) {
    return exp(-pow(distance, 0.9));
}

// Function to calculate the curvature at a given position
std::pair<double, double> CustomSurface::calculateCurvatures(Coordinate3D queryPoint) {

    std::pair<double, double> curvatures = {};
    auto wrong_gradient = calculateGradient(queryPoint);
    Coordinate3D gradient = {wrong_gradient.x, wrong_gradient.y, 0.0};
    Coordinate3D wrong_normal = {gradient.x, gradient.y, -1.0};
    wrong_normal.setMagnitude(1);
    std::array<double, 3> const normal = {wrong_normal.x, wrong_normal.y, wrong_normal.z};

    std::array<std::array<double, 3>, 3> const identity_matrix = {{{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}}};
    std::array<std::array<double, 3>, 3> const matrix_P = matrixSubtraction(identity_matrix, vectorMultiplication(normal, normal));
    std::array<std::array<double, 3>, 3> const hessian_matrix = calculateHessianMatrix(queryPoint);
    std::array<std::array<double, 3>, 3> matrix_G = addFactorToMatrixValues(addFactorToMatrixValues(matrixMultiplication(matrixMultiplication(matrix_P, hessian_matrix), matrix_P), 1 / calculateMagnitude(normal)), -1);

    curvatures.first = matrix_G[0][0];
    curvatures.second = matrix_G[1][1];
    return curvatures;
}

std::array<std::array<double, 3>, 3> CustomSurface::matrixSubtraction(std::array<std::array<double, 3>, 3> matrix1, std::array<std::array<double, 3>, 3> matrix2){
    std::array<std::array<double, 3>, 3> result = {};
    for (int i = 0; i < 3; i++){
        #pragma unroll (5)
        for (int j = 0; j < 3; j++){
            result[i][j] = matrix1[i][j] - matrix2[i][j];
        }
    }
    return result;
}

std::array<std::array<double, 3>, 3> CustomSurface::vectorMultiplication(std::array<double, 3> vector1, std::array<double, 3> vector2){
    std::array<std::array<double, 3>, 3> result = {};
    for (int i = 0; i < 3; i++){
        #pragma unroll (5)
        for (int j = 0; j < 3; j++){
            result[i][j] = vector1[i] * vector2[j];
        }
    }
    return result;
}

std::array<std::array<double, 3>, 3> CustomSurface::matrixMultiplication(std::array<std::array<double, 3>, 3> matrix1, std::array<std::array<double, 3>, 3> matrix2) {
    std::array<std::array<double, 3>, 3> result = {};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            #pragma unroll (5)
            for (int k = 0; k < 3; k++){
                result[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }
    return result;
}

double CustomSurface::sumOfMatrix(std::array<std::array<double, 3>, 3> matrix){
    double result = 0.0;
    for (int i = 0; i < 3; i++) {
        #pragma unroll (5)
        for (int j = 0; j < 3; j++) {
            result += matrix[i][j];
        }
    }
    return result;
}

double CustomSurface::calculateMagnitude(std::array<double, 3> vector){
    double sum = 0.0;
    #pragma unroll (5)
    for (int i = 0; i < 3; i++){
        sum += vector[i]*vector[i];
    }
    return sqrt(sum);
}

std::array<std::array<double, 3>, 3> CustomSurface::addFactorToMatrixValues(std::array<std::array<double, 3>, 3> matrix, double factor){
    std::array<std::array<double, 3>, 3> result = {};
    for (int i = 0; i < 3; i++) {
        #pragma unroll (5)
        for (int j = 0; j < 3; j++) {
            result[i][j] = factor * matrix[i][j];
        }
    }
    return result;
}

// Function to calculate hessian matrix at some point using finite difference
std::array<std::array<double, 3>, 3> CustomSurface::calculateHessianMatrix(Coordinate3D queryPoint){

    double epsilon = 1; // epsilon needs to be 1 for some reason

    // Calculate hessian matrix according to finite difference method
    Coordinate3D const x_plus = {queryPoint.x+epsilon, queryPoint.y, queryPoint.z};
    Coordinate3D const x_minus = {queryPoint.x-epsilon, queryPoint.y, queryPoint.z};
    Coordinate3D const y_plus = {queryPoint.x, queryPoint.y+epsilon, queryPoint.z};
    Coordinate3D const y_minus = {queryPoint.x, queryPoint.y-epsilon, queryPoint.z};
    Coordinate3D const xy_plus = {queryPoint.x+epsilon, queryPoint.y+epsilon, queryPoint.z};
    Coordinate3D const xy_minus = {queryPoint.x-epsilon, queryPoint.y-epsilon, queryPoint.z};
    Coordinate3D const x_plus_y_minus = {queryPoint.x+epsilon, queryPoint.y-epsilon, queryPoint.z};
    Coordinate3D const x_minus_y_plus = {queryPoint.x-epsilon, queryPoint.y+epsilon, queryPoint.z};

    double Lxx = (z_Interpolation(x_plus) - 2* z_Interpolation(queryPoint) +
                  z_Interpolation(x_minus)) /
                 epsilon*epsilon;
    double Lyy = (z_Interpolation(y_plus) - 2* z_Interpolation(queryPoint) +
                  z_Interpolation(y_minus)) /
                 epsilon*epsilon;
    double Lxy = (z_Interpolation(xy_plus) - z_Interpolation(x_plus_y_minus) -
                  z_Interpolation(x_minus_y_plus) + z_Interpolation(xy_minus)) /
                 (4 * epsilon * epsilon);

    std::array<std::array<double, 3>, 3> hessian_matrix = {{{Lxx, Lxy, 0.0}, {Lxy, Lyy, 0.0}, {0.0, 0.0, 0.0}}};
    return hessian_matrix;
}

std::array<double, 16> CustomSurface::construct_aij_vector(int grid_index_i, int grid_index_j){

    // construct vector x
    std::array<double, 16> vector_x = {};
    //first four points are the corner points of the cell
    vector_x[0] = grid_[grid_index_i][grid_index_j].z;
    vector_x[1] = grid_[grid_index_i+1][grid_index_j].z;
    vector_x[2] = grid_[grid_index_i][grid_index_j+1].z;
    vector_x[3] = grid_[grid_index_i+1][grid_index_j+1].z;

    //next 8 points are the derivatives at the corner points of the cell
    interpolation_type_ = "bilinear"; // use bilinear interpolation here because bicubic won't work at this point
    vector_x[4] = calculateGradient(grid_[grid_index_i][grid_index_j]).x;
    vector_x[5] = calculateGradient(grid_[grid_index_i+1][grid_index_j]).x;
    vector_x[6] = calculateGradient(grid_[grid_index_i][grid_index_j+1]).x;
    vector_x[7] = calculateGradient(grid_[grid_index_i+1][grid_index_j+1]).x;
    vector_x[8] = calculateGradient(grid_[grid_index_i][grid_index_j]).y;
    vector_x[9] = calculateGradient(grid_[grid_index_i+1][grid_index_j]).y;
    vector_x[10] = calculateGradient(grid_[grid_index_i][grid_index_j+1]).y;
    vector_x[11] = calculateGradient(grid_[grid_index_i+1][grid_index_j+1]).y;

    // last 4 points are the mixed partial derivatives of the corner points of the cell
    vector_x[12] = calculateHessianMatrix(grid_[grid_index_i][grid_index_j])[0][1];
    vector_x[13] = calculateHessianMatrix(grid_[grid_index_i+1][grid_index_j])[0][1];
    vector_x[14] = calculateHessianMatrix(grid_[grid_index_i][grid_index_j+1])[0][1];
    vector_x[15] = calculateHessianMatrix(grid_[grid_index_i+1][grid_index_j+1])[0][1];
    interpolation_type_ = "bicubic";

    // Consturct aij_vector; calculate A⁻¹x = aij_vector
    std::array<double, 16> aij_vector = matrixVectorMultiplication(inverse_matrix_A_, vector_x);

    return aij_vector;
}

std::array<double, 16> CustomSurface::matrixVectorMultiplication(std::array<std::array<int, 16>, 16> matrix, std::array<double, 16> vector){
    std::array<double, 16> result = {};
    for (int i = 0; i < 16; i++){
        #pragma unroll (5)
        for (int j = 0; j < 16; j++){
            result[i] += matrix[i][j] * vector[j];
        }
    }
    return result;
}

double CustomSurface::power(double base, int exponent) {
    if (base == 0 && exponent == 0) {
        return 1.0;
    }
    return std::pow(base, exponent);
}